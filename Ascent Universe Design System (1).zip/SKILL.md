---
name: ascent-design
description: Use this skill to generate well-branded interfaces and assets for the Ascent Universe (a hard-SF setting of two novels and sixteen short stories spanning ~100,000 BCE to ~3200 CE), either for production or throwaway prototypes/mocks. Contains essential design guidelines, colors, type, fonts, the Dragon's Tooth mark, canonical artwork, and UI kit components for prototyping.
user-invocable: true
---

Read the `readme.md` file within this skill, and explore the other available files — `tokens/` for the CSS variables and fonts, `assets/` for the artwork and the Dragon's Tooth mark, `components/` for the reusable React primitives, and `ui_kits/companion_archive/` for full-screen examples.

If creating visual artifacts (slides, mocks, throwaway prototypes, etc.), copy assets out and create static HTML files for the user to view — link `styles.css`, use the tokens, reach for the chromatic-aberration wordmark, acid-green accent, bone text on green-black ink, and the in-universe dossier/epigraph voice. If working on production code, copy assets and read the rules here to become an expert in designing with this brand.

Core brand reminders: acid green `#c8e021` is the one accent; the Dragon's Tooth is the mark; chromatic red/cyan is the signature glitch treatment; keep radii sharp; depth is glow not shadow; **no emoji**; dates are epoch-stamped (`2479 CE`); section labels are UPPERCASE wide-tracked, the wordmark is lowercase.

If the user invokes this skill without any other guidance, ask them what they want to build or design, ask some questions, and act as an expert designer who outputs HTML artifacts _or_ production code, depending on the need.
