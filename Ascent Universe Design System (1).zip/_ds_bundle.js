/* @ds-bundle: {"format":3,"namespace":"AscentUniverseDesignSystem_d01098","components":[{"name":"Badge","sourcePath":"components/core/Badge.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"FactionTag","sourcePath":"components/core/FactionTag.jsx"},{"name":"GlitchTitle","sourcePath":"components/core/GlitchTitle.jsx"},{"name":"DataRow","sourcePath":"components/data/DataRow.jsx"},{"name":"Panel","sourcePath":"components/data/Panel.jsx"},{"name":"StatBar","sourcePath":"components/data/StatBar.jsx"},{"name":"NavCard","sourcePath":"components/navigation/NavCard.jsx"},{"name":"SectionLabel","sourcePath":"components/navigation/SectionLabel.jsx"},{"name":"Epigraph","sourcePath":"components/reading/Epigraph.jsx"},{"name":"StoryHeader","sourcePath":"components/reading/StoryHeader.jsx"}],"sourceHashes":{"components/core/Badge.jsx":"d21b610f61dc","components/core/Button.jsx":"164d574cb653","components/core/FactionTag.jsx":"0a61defc18dd","components/core/GlitchTitle.jsx":"137225347362","components/data/DataRow.jsx":"12471ce25557","components/data/Panel.jsx":"90e0ffa0ab39","components/data/StatBar.jsx":"ef4fab2e8fb0","components/navigation/NavCard.jsx":"0f9fd4b4ef46","components/navigation/SectionLabel.jsx":"301ce17323ee","components/reading/Epigraph.jsx":"fe4a029bed85","components/reading/StoryHeader.jsx":"9ad8719319ab","ui_kits/companion_archive/Codex.jsx":"834e123f8cdf","ui_kits/companion_archive/Home.jsx":"060c44946226","ui_kits/companion_archive/Nav.jsx":"4c0a5f4d9eed","ui_kits/companion_archive/Reader.jsx":"39757a2ac69f","ui_kits/companion_archive/Worlds.jsx":"f92109183bf4","ui_kits/companion_archive/archiveData.js":"a35c0ee40b86"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.AscentUniverseDesignSystem_d01098 = window.AscentUniverseDesignSystem_d01098 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/core/Badge.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Badge — a small status / classification stamp.
 * Outlined, mono, uppercase. Reads as telemetry or a clearance label.
 */
function Badge({
  children,
  status = 'nominal',
  solid = false,
  style = {},
  ...rest
}) {
  const map = {
    nominal: 'var(--status-nominal)',
    armed: 'var(--status-armed)',
    alert: 'var(--status-alert)',
    standby: 'var(--status-standby)',
    info: 'var(--info)',
    classified: 'var(--chroma-red)'
  };
  const c = map[status] || map.nominal;
  const base = {
    display: 'inline-flex',
    alignItems: 'center',
    gap: '6px',
    fontFamily: 'var(--font-mono)',
    fontSize: 'var(--text-2xs)',
    fontWeight: 'var(--weight-medium)',
    letterSpacing: 'var(--track-wider)',
    textTransform: 'uppercase',
    padding: '3px 8px',
    borderRadius: 'var(--radius-sm)',
    border: '1px solid',
    lineHeight: 1.4,
    ...(solid ? {
      background: c,
      color: 'var(--on-accent)',
      borderColor: c
    } : {
      background: 'transparent',
      color: c,
      borderColor: c
    }),
    ...style
  };
  return /*#__PURE__*/React.createElement("span", _extends({
    style: base
  }, rest), status === 'alert' || status === 'classified' ? /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      width: '5px',
      height: '5px',
      borderRadius: '50%',
      background: solid ? 'var(--on-accent)' : c
    }
  }) : null, children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Badge.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const {
  useState
} = React;
/**
 * Button — the primary action control.
 * Mono, uppercase, wide-tracked: it reads like a command, not a web button.
 */
function Button({
  children,
  variant = 'primary',
  size = 'md',
  disabled = false,
  block = false,
  icon = null,
  href,
  onClick,
  type = 'button',
  style = {},
  ...rest
}) {
  const [hover, setHover] = useState(false);
  const [active, setActive] = useState(false);
  const sizes = {
    sm: {
      padding: '6px 12px',
      fontSize: 'var(--text-2xs)'
    },
    md: {
      padding: '9px 18px',
      fontSize: 'var(--text-xs)'
    },
    lg: {
      padding: '13px 26px',
      fontSize: 'var(--text-sm)'
    }
  };
  const s = sizes[size] || sizes.md;
  const palette = {
    primary: {
      base: {
        background: 'var(--acid)',
        color: 'var(--on-accent)',
        borderColor: 'var(--acid)'
      },
      hover: {
        background: 'var(--acid-bright)',
        borderColor: 'var(--acid-bright)',
        boxShadow: 'var(--glow-acid-strong)'
      },
      active: {
        background: 'var(--acid-deep)',
        borderColor: 'var(--acid-deep)'
      }
    },
    secondary: {
      base: {
        background: 'transparent',
        color: 'var(--bone)',
        borderColor: 'var(--border-strong)'
      },
      hover: {
        color: 'var(--acid)',
        borderColor: 'var(--acid)'
      },
      active: {
        background: 'var(--acid-ghost)'
      }
    },
    ghost: {
      base: {
        background: 'transparent',
        color: 'var(--bone-dim)',
        borderColor: 'transparent'
      },
      hover: {
        color: 'var(--acid)'
      },
      active: {
        color: 'var(--acid-deep)'
      }
    },
    danger: {
      base: {
        background: 'transparent',
        color: 'var(--chroma-red)',
        borderColor: 'var(--chroma-red)'
      },
      hover: {
        background: 'var(--chroma-red)',
        color: 'var(--bone)',
        boxShadow: 'var(--glow-red)'
      },
      active: {
        background: 'var(--chroma-red)'
      }
    }
  };
  const p = palette[variant] || palette.primary;
  const computed = {
    fontFamily: 'var(--font-mono)',
    fontWeight: 'var(--weight-medium)',
    fontSize: s.fontSize,
    letterSpacing: 'var(--track-wider)',
    textTransform: 'uppercase',
    padding: s.padding,
    borderRadius: 'var(--radius-sm)',
    border: '1px solid',
    cursor: disabled ? 'not-allowed' : 'pointer',
    transition: 'all var(--dur-fast) var(--ease-out)',
    display: block ? 'flex' : 'inline-flex',
    width: block ? '100%' : undefined,
    alignItems: 'center',
    justifyContent: 'center',
    gap: '8px',
    whiteSpace: 'nowrap',
    opacity: disabled ? 0.35 : 1,
    transform: active && !disabled ? 'translateY(1px)' : 'none',
    ...p.base,
    ...(hover && !disabled ? p.hover : null),
    ...(active && !disabled ? p.active : null),
    ...style
  };
  const handlers = disabled ? {} : {
    onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => {
      setHover(false);
      setActive(false);
    },
    onMouseDown: () => setActive(true),
    onMouseUp: () => setActive(false)
  };
  const content = /*#__PURE__*/React.createElement(React.Fragment, null, icon ? /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      fontSize: '1.1em',
      lineHeight: 0
    }
  }, icon) : null, children);
  if (href && !disabled) {
    return /*#__PURE__*/React.createElement("a", _extends({
      href: href,
      style: computed
    }, handlers, rest), content);
  }
  return /*#__PURE__*/React.createElement("button", _extends({
    type: type,
    disabled: disabled,
    style: computed
  }, handlers, rest), content);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/FactionTag.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const FACTIONS = {
  arco: {
    color: 'var(--arco)',
    label: 'Arco'
  },
  union: {
    color: 'var(--union)',
    label: 'Union'
  },
  dyn: {
    color: 'var(--dyn)',
    label: 'The Dyn'
  },
  striver: {
    color: 'var(--striver)',
    label: 'Strivers'
  },
  apathy: {
    color: 'var(--apathy)',
    label: 'The Apathy'
  },
  utilitaria: {
    color: 'var(--utilitaria)',
    label: 'Utilitaria'
  },
  listener: {
    color: 'var(--listener)',
    label: 'The Listener'
  },
  seeker: {
    color: 'var(--seeker)',
    label: 'Seeker'
  }
};

/**
 * FactionTag — a colour-coded entity marker for the codex, threads & dossiers.
 * A small diamond in the faction hue + its name (override with children).
 */
function FactionTag({
  faction = 'arco',
  children,
  size = 'md',
  style = {},
  ...rest
}) {
  const f = FACTIONS[faction] || FACTIONS.arco;
  const fs = size === 'sm' ? 'var(--text-2xs)' : 'var(--text-xs)';
  const d = size === 'sm' ? 7 : 9;
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: '7px',
      fontFamily: 'var(--font-mono)',
      fontSize: fs,
      letterSpacing: 'var(--track-wide)',
      textTransform: 'uppercase',
      color: 'var(--bone)',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      width: `${d}px`,
      height: `${d}px`,
      background: f.color,
      flex: 'none',
      clipPath: 'polygon(50% 0%, 100% 50%, 50% 100%, 0% 50%)',
      boxShadow: `0 0 8px ${f.color}`
    }
  }), children || f.label);
}
Object.assign(__ds_scope, { FactionTag });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/FactionTag.jsx", error: String((e && e.message) || e) }); }

// components/core/GlitchTitle.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const {
  useState
} = React;
/**
 * GlitchTitle — text with the cover's red/cyan chromatic-aberration treatment.
 * The signature title style of the universe. Optionally intensifies on hover.
 */
function GlitchTitle({
  children,
  as: Tag = 'h2',
  size = 'xl',
  weight = 300,
  lowercase = true,
  intensify = true,
  style = {},
  ...rest
}) {
  const [hover, setHover] = useState(false);
  const sizes = {
    sm: 'var(--text-lg)',
    md: 'var(--text-xl)',
    lg: 'var(--text-2xl)',
    xl: 'var(--text-3xl)',
    hero: 'var(--text-hero)'
  };
  const offset = hover && intensify ? '0.07em' : '0.045em';
  const computed = {
    fontFamily: 'var(--font-display)',
    fontWeight: weight,
    fontSize: sizes[size] || sizes.xl,
    lineHeight: 'var(--leading-tight)',
    letterSpacing: 'var(--track-widest)',
    textTransform: lowercase ? 'lowercase' : 'none',
    color: 'var(--bone)',
    textShadow: `${offset} 0 var(--chroma-red), -${offset} 0 var(--chroma-cyan)`,
    transition: 'text-shadow var(--dur) var(--ease-out)',
    margin: 0,
    ...style
  };
  return /*#__PURE__*/React.createElement(Tag, _extends({
    style: computed,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false)
  }, rest), children);
}
Object.assign(__ds_scope, { GlitchTitle });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/GlitchTitle.jsx", error: String((e && e.message) || e) }); }

// components/data/DataRow.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * DataRow — a single label/value line for dossiers and spec sheets.
 * Mono, hairline-separated, with an optional sub-line and value tone.
 */
function DataRow({
  label,
  value,
  sub,
  tone = 'default',
  last = false,
  style = {},
  ...rest
}) {
  const tones = {
    default: 'var(--bone)',
    acid: 'var(--acid)',
    alert: 'var(--chroma-red)',
    info: 'var(--info)',
    dim: 'var(--bone-dim)',
    warn: 'var(--arco)'
  };
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'baseline',
      gap: 'var(--space-4)',
      padding: '6px 0',
      borderBottom: last ? 'none' : '1px solid var(--bone-hair)',
      fontFamily: 'var(--font-mono)',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-xs)',
      color: 'var(--bone-faint)',
      letterSpacing: 'var(--track-wide)',
      textTransform: 'uppercase',
      flex: 'none',
      maxWidth: '46%'
    }
  }, label), /*#__PURE__*/React.createElement("span", {
    style: {
      textAlign: 'right',
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-xs)',
      color: tones[tone] || tones.default,
      letterSpacing: '0.02em'
    }
  }, value), sub != null ? /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'block',
      fontSize: 'var(--text-2xs)',
      color: 'var(--bone-ghost)',
      marginTop: '2px'
    }
  }, sub) : null));
}
Object.assign(__ds_scope, { DataRow });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/DataRow.jsx", error: String((e && e.message) || e) }); }

// components/data/Panel.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Panel — the core dossier / telemetry surface.
 * Hairline-bordered card with an optional titled header and a right slot.
 */
function Panel({
  title,
  badge,
  accent = 'var(--acid)',
  children,
  style = {},
  bodyStyle = {},
  ...rest
}) {
  return /*#__PURE__*/React.createElement("section", _extends({
    style: {
      background: 'var(--surface)',
      border: '1px solid var(--border)',
      borderRadius: 'var(--radius-md)',
      boxShadow: 'var(--shadow-panel)',
      overflow: 'hidden',
      ...style
    }
  }, rest), title != null && /*#__PURE__*/React.createElement("header", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      gap: 'var(--space-3)',
      padding: 'var(--space-3) var(--space-4)',
      borderBottom: '1px solid var(--border)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: '10px',
      fontFamily: 'var(--font-display)',
      fontSize: 'var(--text-sm)',
      fontWeight: 'var(--weight-semibold)',
      letterSpacing: 'var(--track-wider)',
      textTransform: 'uppercase',
      color: 'var(--bone)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      width: '3px',
      height: '13px',
      background: accent,
      display: 'inline-block'
    }
  }), title), badge != null ? /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 'none'
    }
  }, badge) : null), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 'var(--space-4)',
      ...bodyStyle
    }
  }, children));
}
Object.assign(__ds_scope, { Panel });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/Panel.jsx", error: String((e && e.message) || e) }); }

// components/data/StatBar.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * StatBar — a labelled telemetry meter (power, integrity, charge…).
 * Thin track + animated acid fill, with a mono header row.
 */
function StatBar({
  label,
  value = 0,
  max = 100,
  color = 'var(--acid)',
  unit = '%',
  showValue = true,
  style = {},
  ...rest
}) {
  const pct = Math.max(0, Math.min(100, value / max * 100));
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-2xs)',
      letterSpacing: 'var(--track-wide)',
      textTransform: 'uppercase',
      color: 'var(--bone-faint)',
      marginBottom: '5px'
    }
  }, /*#__PURE__*/React.createElement("span", null, label), showValue ? /*#__PURE__*/React.createElement("span", {
    style: {
      color
    }
  }, Math.round(value), unit) : null), /*#__PURE__*/React.createElement("div", {
    style: {
      height: '4px',
      background: 'var(--bone-hair)',
      borderRadius: 'var(--radius-pill)',
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      height: '100%',
      width: `${pct}%`,
      background: color,
      borderRadius: 'var(--radius-pill)',
      boxShadow: `0 0 10px ${color}`,
      transition: 'width var(--dur-slow) var(--ease-out)'
    }
  })));
}
Object.assign(__ds_scope, { StatBar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/StatBar.jsx", error: String((e && e.message) || e) }); }

// components/navigation/NavCard.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const {
  useState
} = React;
/**
 * NavCard — the hub navigation tile, styled as a dossier / targeting reticle:
 * corner brackets and a faint file index instead of a plain bordered box.
 * A classification kicker, a display title, a description and an arrow.
 * Hover washes the cell, lights the brackets and nudges the chromatic title.
 */
function NavCard({
  kicker,
  title,
  children,
  href = '#',
  accent = 'var(--acid)',
  glyph,
  index,
  wide = false,
  style = {},
  ...rest
}) {
  const [hover, setHover] = useState(false);
  const bracketColor = hover ? accent : 'var(--border-strong)';
  const b = 'var(--space-3)'; // bracket inset
  const corner = pos => {
    const size = 13,
      t = 1.5;
    const base = {
      position: 'absolute',
      width: `${size}px`,
      height: `${size}px`,
      transition: 'border-color var(--dur) var(--ease-out), opacity var(--dur) var(--ease-out)',
      pointerEvents: 'none',
      opacity: hover ? 1 : 0.7
    };
    const e = {
      ...base
    };
    if (pos.includes('t')) {
      e.top = b;
      e.borderTop = `${t}px solid ${bracketColor}`;
    }
    if (pos.includes('b')) {
      e.bottom = b;
      e.borderBottom = `${t}px solid ${bracketColor}`;
    }
    if (pos.includes('l')) {
      e.left = b;
      e.borderLeft = `${t}px solid ${bracketColor}`;
    }
    if (pos.includes('r')) {
      e.right = b;
      e.borderRight = `${t}px solid ${bracketColor}`;
    }
    return /*#__PURE__*/React.createElement("span", {
      key: pos,
      "aria-hidden": "true",
      style: e
    });
  };
  return /*#__PURE__*/React.createElement("a", _extends({
    href: href,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      position: 'relative',
      display: 'block',
      gridColumn: wide ? '1 / -1' : undefined,
      padding: 'var(--space-5) var(--space-6)',
      textDecoration: 'none',
      background: hover ? 'var(--acid-ghost)' : 'transparent',
      boxShadow: hover ? 'var(--glow-acid)' : 'none',
      transition: 'background var(--dur) var(--ease-out), box-shadow var(--dur) var(--ease-out)',
      overflow: 'hidden',
      ...style
    }
  }, rest), ['tl', 'tr', 'bl', 'br'].map(corner), index != null && /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      position: 'absolute',
      right: 'var(--space-5)',
      top: 'var(--space-3)',
      fontFamily: 'var(--font-mono)',
      fontWeight: 700,
      fontSize: '2.8rem',
      lineHeight: 1,
      color: hover ? 'rgba(200,224,33,0.14)' : 'var(--bone-hair)',
      letterSpacing: '-0.04em',
      transition: 'color var(--dur) var(--ease-out)',
      userSelect: 'none'
    }
  }, String(index).padStart(2, '0')), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: '9px',
      marginBottom: 'var(--space-3)',
      position: 'relative',
      zIndex: 1
    }
  }, /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      width: '7px',
      height: '7px',
      flex: 'none',
      background: accent,
      clipPath: 'polygon(50% 0%, 100% 50%, 50% 100%, 0% 50%)',
      boxShadow: hover ? `0 0 8px ${accent}` : 'none',
      transition: 'box-shadow var(--dur) var(--ease-out)'
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-2xs)',
      letterSpacing: 'var(--track-wider)',
      textTransform: 'uppercase',
      color: hover ? 'var(--acid)' : 'var(--bone-faint)',
      transition: 'color var(--dur) var(--ease-out)'
    }
  }, kicker), glyph ? /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      fontSize: 'var(--text-base)',
      color: accent,
      lineHeight: 1,
      marginLeft: '2px'
    }
  }, glyph) : null), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 'var(--weight-semibold)',
      fontSize: 'var(--text-lg)',
      letterSpacing: 'var(--track-wide)',
      color: 'var(--bone)',
      marginBottom: 'var(--space-2)',
      position: 'relative',
      zIndex: 1,
      textShadow: hover ? '0.03em 0 var(--chroma-red), -0.03em 0 var(--chroma-cyan)' : 'none',
      transition: 'text-shadow var(--dur) var(--ease-out)'
    }
  }, title), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--text-sm)',
      lineHeight: 'var(--leading-normal)',
      color: 'var(--bone-dim)',
      maxWidth: '54ch',
      position: 'relative',
      zIndex: 1,
      paddingRight: 'var(--space-5)'
    }
  }, children), /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      position: 'absolute',
      right: 'var(--space-5)',
      bottom: 'var(--space-4)',
      color: hover ? 'var(--acid)' : 'var(--bone-faint)',
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-lg)',
      transform: `translateX(${hover ? '3px' : '0'})`,
      transition: 'all var(--dur) var(--ease-out)',
      zIndex: 1
    }
  }, "\u2192"));
}
Object.assign(__ds_scope, { NavCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/NavCard.jsx", error: String((e && e.message) || e) }); }

// components/navigation/SectionLabel.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * SectionLabel — a hub/section header: a small mono label above a hairline
 * rule with an acid tick. The organising device of the archive.
 */
function SectionLabel({
  children,
  accent = 'var(--acid)',
  style = {},
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-2xs)',
      letterSpacing: 'var(--track-widest)',
      textTransform: 'uppercase',
      color: 'var(--bone-dim)',
      marginBottom: 'var(--space-2)'
    }
  }, children), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      height: '1px',
      background: 'var(--border)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      position: 'absolute',
      left: 0,
      top: 0,
      width: '40px',
      height: '1px',
      background: accent
    }
  })));
}
Object.assign(__ds_scope, { SectionLabel });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/SectionLabel.jsx", error: String((e && e.message) || e) }); }

// components/reading/Epigraph.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Epigraph — the chapter epigraph block: an italic serif quote with an
 * em-dashed attribution, set off by an acid left rule. Pure Ascent voice.
 */
function Epigraph({
  children,
  cite,
  align = 'left',
  style = {},
  ...rest
}) {
  return /*#__PURE__*/React.createElement("figure", _extends({
    style: {
      margin: 0,
      borderLeft: align === 'left' ? '2px solid var(--acid)' : 'none',
      paddingLeft: align === 'left' ? 'var(--space-4)' : 0,
      textAlign: align,
      maxWidth: '52ch',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("blockquote", {
    style: {
      margin: 0,
      fontFamily: 'var(--font-serif)',
      fontStyle: 'italic',
      fontSize: 'var(--text-md)',
      lineHeight: 'var(--leading-snug)',
      color: 'var(--bone-soft)',
      textWrap: 'pretty'
    }
  }, children), cite ? /*#__PURE__*/React.createElement("figcaption", {
    style: {
      marginTop: 'var(--space-3)',
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-2xs)',
      letterSpacing: 'var(--track-wide)',
      textTransform: 'uppercase',
      color: 'var(--bone-faint)'
    }
  }, "\u2014 ", cite) : null);
}
Object.assign(__ds_scope, { Epigraph });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/reading/Epigraph.jsx", error: String((e && e.message) || e) }); }

// components/reading/StoryHeader.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * StoryHeader — the masthead of a story / scene reader: a mono classification
 * line (era · attribution), the title, and an optional location subtitle.
 */
function StoryHeader({
  kicker,
  title,
  subtitle,
  faction,
  style = {},
  ...rest
}) {
  const factionColor = {
    arco: 'var(--arco)',
    union: 'var(--union)',
    dyn: 'var(--dyn)',
    striver: 'var(--striver)',
    apathy: 'var(--apathy)',
    utilitaria: 'var(--utilitaria)',
    listener: 'var(--listener)',
    seeker: 'var(--seeker)'
  }[faction] || 'var(--acid)';
  return /*#__PURE__*/React.createElement("header", _extends({
    style: {
      ...style
    }
  }, rest), kicker ? /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: '10px',
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-2xs)',
      letterSpacing: 'var(--track-wider)',
      textTransform: 'uppercase',
      color: 'var(--bone-faint)',
      marginBottom: 'var(--space-3)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      width: '24px',
      height: '1px',
      background: factionColor
    }
  }), kicker) : null, /*#__PURE__*/React.createElement("h1", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 'var(--weight-semibold)',
      fontSize: 'var(--text-2xl)',
      letterSpacing: 'var(--track-tight)',
      lineHeight: 'var(--leading-tight)',
      color: 'var(--bone)',
      margin: 0
    }
  }, title), subtitle ? /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--text-sm)',
      color: 'var(--bone-dim)',
      marginTop: 'var(--space-2)',
      letterSpacing: 'var(--track-wide)'
    }
  }, subtitle) : null);
}
Object.assign(__ds_scope, { StoryHeader });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/reading/StoryHeader.jsx", error: String((e && e.message) || e) }); }

// ui_kits/companion_archive/Codex.jsx
try { (() => {
/* Codex.jsx — interactive intelligence dossiers. */
const {
  useState: useCodexState
} = React;
function CodexScreen() {
  const {
    Panel,
    DataRow,
    StatBar,
    Badge,
    FactionTag,
    SectionLabel
  } = window.AscentUniverseDesignSystem_d01098;
  const entries = window.ARCHIVE.codex;
  const [activeId, setActiveId] = useCodexState(entries[0].id);
  const active = entries.find(e => e.id === activeId) || entries[0];
  const threatTone = t => t === 'EXISTENTIAL' || t === 'CRITICAL' ? 'alert' : t === 'DORMANT' || t === 'COOPERATIVE' ? 'acid' : 'dim';
  return /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--width-content)',
      margin: '0 auto',
      padding: 'var(--space-8) var(--space-6) var(--space-12)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: 'var(--space-3)',
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-2xs)',
      letterSpacing: 'var(--track-widest)',
      textTransform: 'uppercase',
      color: 'var(--chroma-red)'
    }
  }, "\u25C8 Classified \u2014 Arco Intelligence Codex"), /*#__PURE__*/React.createElement("h1", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 600,
      fontSize: 'var(--text-2xl)',
      letterSpacing: 'var(--track-tight)',
      color: 'var(--bone)',
      marginBottom: 'var(--space-8)'
    }
  }, "Intelligence Codex"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '280px 1fr',
      gap: 'var(--space-6)',
      alignItems: 'start'
    }
  }, /*#__PURE__*/React.createElement("aside", null, /*#__PURE__*/React.createElement(SectionLabel, {
    style: {
      marginBottom: 'var(--space-4)'
    }
  }, "Dossiers"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: '2px'
    }
  }, entries.map(e => {
    const on = e.id === activeId;
    return /*#__PURE__*/React.createElement("button", {
      key: e.id,
      onClick: () => setActiveId(e.id),
      style: {
        textAlign: 'left',
        padding: 'var(--space-3)',
        borderRadius: 'var(--radius-sm)',
        border: '1px solid',
        borderColor: on ? 'var(--border-acid)' : 'transparent',
        background: on ? 'var(--acid-ghost)' : 'transparent',
        transition: 'all var(--dur-fast) var(--ease-out)',
        cursor: 'pointer'
      },
      onMouseEnter: ev => {
        if (!on) ev.currentTarget.style.background = 'var(--surface)';
      },
      onMouseLeave: ev => {
        if (!on) ev.currentTarget.style.background = 'transparent';
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        marginBottom: '6px'
      }
    }, /*#__PURE__*/React.createElement(FactionTag, {
      faction: e.faction,
      size: "sm"
    }, e.kind)), /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: 'var(--font-display)',
        fontWeight: 600,
        fontSize: 'var(--text-sm)',
        color: on ? 'var(--acid)' : 'var(--bone)',
        letterSpacing: 'var(--track-wide)'
      }
    }, e.name));
  }))), /*#__PURE__*/React.createElement(Panel, {
    title: active.name,
    accent: `var(--${active.faction})`,
    badge: /*#__PURE__*/React.createElement(Badge, {
      status: threatTone(active.threat) === 'alert' ? 'alert' : 'nominal'
    }, active.threat)
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-4)',
      marginBottom: 'var(--space-4)',
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement(FactionTag, {
    faction: active.faction
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-2xs)',
      letterSpacing: 'var(--track-wide)',
      color: 'var(--bone-faint)'
    }
  }, active.kind, " \xB7 ", active.era)), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: 'var(--font-serif)',
      fontSize: 'var(--text-base)',
      lineHeight: 'var(--leading-reading)',
      color: 'var(--bone-soft)',
      marginBottom: 'var(--space-5)',
      maxWidth: '64ch'
    }
  }, active.summary), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: 'var(--space-6)'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-2xs)',
      letterSpacing: 'var(--track-wider)',
      textTransform: 'uppercase',
      color: 'var(--bone-faint)',
      marginBottom: 'var(--space-2)'
    }
  }, "Specification"), active.rows.map((r, i) => /*#__PURE__*/React.createElement(DataRow, {
    key: r.label,
    label: r.label,
    value: r.value,
    tone: r.tone,
    last: i === active.rows.length - 1
  }))), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-2xs)',
      letterSpacing: 'var(--track-wider)',
      textTransform: 'uppercase',
      color: 'var(--bone-faint)',
      marginBottom: 'var(--space-3)'
    }
  }, "Assessment"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-4)'
    }
  }, active.stats.map(s => /*#__PURE__*/React.createElement(StatBar, {
    key: s.label,
    label: s.label,
    value: s.value,
    color: s.color || 'var(--acid)'
  }))))))));
}
window.CodexScreen = CodexScreen;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/companion_archive/Codex.jsx", error: String((e && e.message) || e) }); }

// ui_kits/companion_archive/Home.jsx
try { (() => {
/* Home.jsx — the Ascent Universe frontpage. */
const {
  useEffect: useHomeEffect,
  useRef: useHomeRef
} = React;
function Starfield() {
  const ref = useHomeRef(null);
  useHomeEffect(() => {
    const c = ref.current;
    if (!c) return;
    const ctx = c.getContext('2d');
    let raf,
      t = 0;
    const resize = () => {
      c.width = c.offsetWidth;
      c.height = c.offsetHeight;
    };
    resize();
    const stars = Array.from({
      length: 150
    }, () => ({
      x: Math.random(),
      y: Math.random(),
      s: Math.random() * 1.4 + 0.3,
      b: Math.random(),
      sp: Math.random() * 0.5 + 0.15
    }));
    const draw = () => {
      raf = requestAnimationFrame(draw);
      t += 0.01;
      ctx.clearRect(0, 0, c.width, c.height);
      for (const st of stars) {
        ctx.fillStyle = `rgba(200,224,33,${0.10 + Math.sin(t * st.sp + st.b * 6.28) * 0.10})`;
        ctx.beginPath();
        ctx.arc(st.x * c.width, st.y * c.height, st.s, 0, Math.PI * 2);
        ctx.fill();
      }
    };
    draw();
    window.addEventListener('resize', resize);
    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener('resize', resize);
    };
  }, []);
  return /*#__PURE__*/React.createElement("canvas", {
    ref: ref,
    style: {
      position: 'absolute',
      inset: 0,
      width: '100%',
      height: '100%',
      zIndex: 0
    }
  });
}
function HomeScreen({
  onNavigate
}) {
  const {
    GlitchTitle,
    NavCard,
    SectionLabel,
    Button,
    Epigraph,
    FactionTag
  } = window.AscentUniverseDesignSystem_d01098;
  const A = window.ARCHIVE;
  let fileNo = 0;
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("header", {
    className: "ax-grunge ax-grain",
    style: {
      position: 'relative',
      overflow: 'hidden',
      borderBottom: '1px solid var(--border)'
    }
  }, /*#__PURE__*/React.createElement(Starfield, null), /*#__PURE__*/React.createElement("div", {
    className: "ax-scanlines"
  }), /*#__PURE__*/React.createElement("img", {
    src: "../../assets/brand/dragons-tooth-acid.png",
    alt: "",
    "aria-hidden": "true",
    style: {
      position: 'absolute',
      right: '-3%',
      top: '50%',
      transform: 'translateY(-50%)',
      height: '118%',
      width: 'auto',
      opacity: 0.06,
      zIndex: 1,
      pointerEvents: 'none'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      zIndex: 4,
      maxWidth: 'var(--width-content)',
      margin: '0 auto',
      padding: 'var(--space-16) var(--space-6) var(--space-12)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-2xs)',
      letterSpacing: 'var(--track-widest)',
      textTransform: 'uppercase',
      color: 'var(--bone-dim)',
      marginBottom: 'var(--space-5)'
    }
  }, "Ascent Universe ", /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--acid)'
    }
  }, "//"), " Companion Archive"), /*#__PURE__*/React.createElement(GlitchTitle, {
    as: "h1",
    size: "hero",
    weight: 300,
    style: {
      marginBottom: 'var(--space-4)'
    }
  }, "ascent"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-4)',
      marginBottom: 'var(--space-5)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: '64px',
      height: '1px',
      background: 'var(--acid)'
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-sm)',
      letterSpacing: 'var(--track-wider)',
      color: 'var(--bone-soft)'
    }
  }, "~100,000 BCE \u2014 ~3200 CE")), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--text-md)',
      fontWeight: 400,
      lineHeight: 'var(--leading-normal)',
      color: 'var(--bone-soft)',
      maxWidth: '60ch',
      marginBottom: 'var(--space-3)'
    }
  }, "A science fiction universe spanning a hundred thousand years. Two novels and sixteen short stories trace the collision between humanity and the alien ", /*#__PURE__*/React.createElement("strong", {
    style: {
      color: 'var(--dyn)',
      fontWeight: 500
    }
  }, "Dyn"), " \u2014 from deep prehistory to the far-future war against the ", /*#__PURE__*/React.createElement("strong", {
    style: {
      color: 'var(--apathy)',
      fontWeight: 500
    }
  }, "Apathy"), ", a force that may be killing us for our own good."), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--text-sm)',
      lineHeight: 'var(--leading-normal)',
      color: 'var(--bone-dim)',
      maxWidth: '58ch',
      marginBottom: 'var(--space-6)'
    }
  }, "Story readers, tactical reconstructions, intelligence dossiers and 3D models, built around the source fiction."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 'var(--space-3)',
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "lg",
    icon: "\u25A3",
    onClick: () => onNavigate('reader')
  }, "Enter the Archive"), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    size: "lg",
    icon: "\u25C8",
    onClick: () => onNavigate('codex')
  }, "Intelligence Codex")))), /*#__PURE__*/React.createElement("section", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1.1fr 1fr',
      alignItems: 'stretch',
      maxWidth: 'var(--width-wide)',
      margin: '0 auto',
      borderBottom: '1px solid var(--border)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      minHeight: '380px',
      borderRight: '1px solid var(--border)',
      overflow: 'hidden',
      background: 'var(--ink-950)'
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/art/dyn-and-conscience.webp",
    alt: "A Dyn and Her Conscience",
    style: {
      position: 'absolute',
      inset: 0,
      width: '100%',
      height: '100%',
      objectFit: 'cover',
      objectPosition: 'center',
      filter: 'grayscale(0.1) contrast(1.05) brightness(0.92)'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      background: 'linear-gradient(90deg, transparent 55%, rgba(8,11,8,0.85) 100%)'
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      left: 'var(--space-5)',
      bottom: 'var(--space-4)',
      zIndex: 2,
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-2xs)',
      letterSpacing: 'var(--track-wide)',
      color: 'var(--ink-950)',
      background: 'var(--bone)',
      padding: '3px 8px',
      borderRadius: 'var(--radius-sm)'
    }
  }, "PLATE 01 \xB7 A DYN AND HER CONSCIENCE")), /*#__PURE__*/React.createElement("div", {
    className: "ax-grunge",
    style: {
      padding: 'var(--space-10) var(--space-8)',
      display: 'flex',
      flexDirection: 'column',
      justifyContent: 'center',
      gap: 'var(--space-5)'
    }
  }, /*#__PURE__*/React.createElement(FactionTag, {
    faction: "dyn"
  }, "The Dyn"), /*#__PURE__*/React.createElement(Epigraph, {
    cite: "Starwhisp \u2014 K'txl's assessment"
  }, "Virulent ideas rule your minds. That is why you are insane \u2014 and why you cannot be allowed to continue."), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: 'var(--font-serif)',
      fontSize: 'var(--text-base)',
      lineHeight: 'var(--leading-reading)',
      color: 'var(--bone-dim)',
      maxWidth: '46ch'
    }
  }, "Y-shaped, jaw-plated, bound by pheromone into a single Line across ten thousand generations. No concept of morality, trade or compromise \u2014 only dominance, submission, and the survival of the whole. They invaded not from malice, but from a cold and rational fear of what our conscience would compel us to do."), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Button, {
    variant: "ghost",
    icon: "\u2192",
    onClick: () => onNavigate('codex')
  }, "Open the Dyn dossier")))), /*#__PURE__*/React.createElement("main", {
    style: {
      maxWidth: 'var(--width-content)',
      margin: '0 auto',
      padding: 'var(--space-10) var(--space-6) var(--space-12)'
    }
  }, A.navSections.map(sec => /*#__PURE__*/React.createElement("div", {
    key: sec.label,
    style: {
      marginBottom: 'var(--space-10)'
    }
  }, /*#__PURE__*/React.createElement(SectionLabel, {
    style: {
      marginBottom: 'var(--space-5)'
    }
  }, sec.label), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(2, 1fr)',
      gap: 'var(--space-4)'
    }
  }, sec.cards.map(card => /*#__PURE__*/React.createElement(NavCard, {
    key: card.title,
    kicker: card.kicker,
    title: card.title,
    glyph: card.glyph,
    accent: card.accent,
    wide: card.wide,
    index: fileNo += 1,
    href: "#",
    onClick: e => {
      e.preventDefault();
      onNavigate(card.target);
    }
  }, card.desc)))))), /*#__PURE__*/React.createElement("section", {
    style: {
      borderTop: '1px solid var(--border)',
      background: 'var(--ink-950)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--width-content)',
      margin: '0 auto',
      padding: 'var(--space-10) var(--space-6)'
    }
  }, /*#__PURE__*/React.createElement(SectionLabel, {
    style: {
      marginBottom: 'var(--space-5)'
    }
  }, "Dramatis Personae"), /*#__PURE__*/React.createElement("figure", {
    style: {
      margin: 0,
      position: 'relative',
      border: '1px solid var(--border)',
      borderRadius: 'var(--radius-md)',
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/art/portraits-triptych.jpg",
    alt: "Aurelie, Vash and the Emissary",
    style: {
      width: '100%',
      height: 'auto',
      display: 'block',
      filter: 'grayscale(0.12) contrast(1.03)'
    }
  }), /*#__PURE__*/React.createElement("figcaption", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(3, 1fr)',
      borderTop: '1px solid var(--border)',
      background: 'var(--surface)'
    }
  }, [{
    c: 'var(--acid)',
    n: 'Aurelie',
    d: 'Christo\u2019s lieutenant — and the hand on the warseeds'
  }, {
    c: 'var(--bone)',
    n: 'Vash',
    d: 'Arco\u2019s Ambassador — the lesser evil, made flesh'
  }, {
    c: 'var(--listener)',
    n: 'The Emissary',
    d: 'A sub-unit of the dead Utilitaria — the last echo of a god-mind'
  }].map((p, i) => /*#__PURE__*/React.createElement("div", {
    key: p.n,
    style: {
      padding: 'var(--space-4)',
      borderRight: i < 2 ? '1px solid var(--border)' : 'none'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 600,
      fontSize: 'var(--text-base)',
      color: p.c,
      letterSpacing: 'var(--track-wide)'
    }
  }, p.n), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--text-sm)',
      color: 'var(--bone-dim)',
      marginTop: '4px'
    }
  }, p.d))))))), /*#__PURE__*/React.createElement("section", {
    className: "ax-grunge",
    style: {
      borderTop: '1px solid var(--border)',
      textAlign: 'center',
      padding: 'var(--space-12) var(--space-6)'
    }
  }, /*#__PURE__*/React.createElement(Epigraph, {
    align: "center",
    cite: "The Listener",
    style: {
      margin: '0 auto var(--space-6)'
    }
  }, "I am everything, it said. And for once, that was not a lie."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      gap: '12px'
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/brand/dragons-tooth.png",
    alt: "",
    style: {
      height: '28px',
      opacity: 0.8
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 300,
      fontSize: 'var(--text-lg)',
      letterSpacing: 'var(--track-widest)',
      color: 'var(--bone-dim)',
      textTransform: 'lowercase'
    }
  }, "ascent"))));
}
window.HomeScreen = HomeScreen;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/companion_archive/Home.jsx", error: String((e && e.message) || e) }); }

// ui_kits/companion_archive/Nav.jsx
try { (() => {
/* Nav.jsx — shared top navigation + status bar for the Companion Archive. */
const {
  useState: useNavState
} = React;
function NavLink({
  label,
  active,
  onSelect
}) {
  const [hover, setHover] = useNavState(false);
  const style = {
    fontFamily: 'var(--font-mono)',
    fontSize: 'var(--text-2xs)',
    letterSpacing: 'var(--track-wider)',
    textTransform: 'uppercase',
    padding: '6px 11px',
    borderRadius: 'var(--radius-sm)',
    border: '1px solid transparent',
    background: 'transparent',
    color: active || hover ? 'var(--acid)' : 'var(--bone-dim)',
    textDecoration: 'none'
  };
  if (active) {
    style.borderColor = 'var(--border-acid)';
    style.background = 'var(--acid-ghost)';
  }
  return /*#__PURE__*/React.createElement("a", {
    href: "#",
    onClick: e => {
      e.preventDefault();
      onSelect();
    },
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: style
  }, label);
}
function Nav({
  current,
  onNavigate
}) {
  const links = [{
    id: 'home',
    label: 'Home'
  }, {
    id: 'reader',
    label: 'Stories'
  }, {
    id: 'codex',
    label: 'Codex'
  }, {
    id: 'worlds',
    label: 'Worlds'
  }];
  return /*#__PURE__*/React.createElement("nav", {
    style: {
      position: 'sticky',
      top: 0,
      zIndex: 100,
      height: 'var(--nav-height)',
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-4)',
      padding: '0 var(--space-5)',
      background: 'rgba(8, 11, 8, 0.82)',
      borderBottom: '1px solid var(--border)',
      backdropFilter: 'blur(14px)'
    }
  }, /*#__PURE__*/React.createElement("a", {
    href: "#",
    onClick: e => {
      e.preventDefault();
      onNavigate('home');
    },
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: '10px',
      textDecoration: 'none',
      flex: 'none'
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/brand/dragons-tooth.png",
    alt: "",
    style: {
      height: '22px',
      width: 'auto'
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 300,
      fontSize: 'var(--text-base)',
      letterSpacing: 'var(--track-widest)',
      color: 'var(--bone)',
      textTransform: 'lowercase',
      textShadow: 'var(--chroma-text-soft)'
    }
  }, "ascent")), /*#__PURE__*/React.createElement("span", {
    style: {
      width: '1px',
      height: '18px',
      background: 'var(--border)',
      flex: 'none'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: '2px',
      flex: 1
    }
  }, links.map(l => /*#__PURE__*/React.createElement(NavLink, {
    key: l.id + (current === l.id ? '-on' : '-off'),
    label: l.label,
    active: current === l.id,
    onSelect: () => onNavigate(l.id)
  }))), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-2xs)',
      letterSpacing: 'var(--track-wide)',
      color: 'var(--bone-faint)',
      flex: 'none'
    }
  }, "COMPANION ARCHIVE"));
}
function StatusBar({
  note
}) {
  return /*#__PURE__*/React.createElement("footer", {
    style: {
      position: 'sticky',
      bottom: 0,
      zIndex: 90,
      height: 'var(--status-height)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      padding: '0 var(--space-5)',
      background: 'rgba(8, 11, 8, 0.9)',
      borderTop: '1px solid var(--border)',
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-2xs)',
      letterSpacing: 'var(--track-wide)',
      color: 'var(--bone-faint)'
    }
  }, /*#__PURE__*/React.createElement("span", null, /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--acid)'
    }
  }, "\u25CF"), " ARCHIVE ONLINE"), /*#__PURE__*/React.createElement("span", null, note || '~100,000 BCE — ~3200 CE'), /*#__PURE__*/React.createElement("span", null, "ARCO GEN-STREAM"));
}
window.Nav = Nav;
window.StatusBar = StatusBar;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/companion_archive/Nav.jsx", error: String((e && e.message) || e) }); }

// ui_kits/companion_archive/Reader.jsx
try { (() => {
/* Reader.jsx — literary story reader. */
const {
  useState: useReaderState
} = React;
function ReaderScreen() {
  const {
    StoryHeader,
    Epigraph,
    FactionTag,
    Button
  } = window.AscentUniverseDesignSystem_d01098;
  const stories = window.ARCHIVE.stories;
  const [idx, setIdx] = useReaderState(0);
  const s = stories[idx];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '240px 1fr',
      minHeight: 'calc(100vh - var(--nav-height) - var(--status-height))'
    }
  }, /*#__PURE__*/React.createElement("aside", {
    style: {
      borderRight: '1px solid var(--border)',
      padding: 'var(--space-6) var(--space-4)',
      position: 'sticky',
      top: 'var(--nav-height)',
      alignSelf: 'start'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-2xs)',
      letterSpacing: 'var(--track-widest)',
      textTransform: 'uppercase',
      color: 'var(--bone-dim)',
      marginBottom: 'var(--space-4)'
    }
  }, "Contents"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: '6px'
    }
  }, stories.map((st, i) => {
    const on = i === idx;
    return /*#__PURE__*/React.createElement("button", {
      key: st.id,
      onClick: () => setIdx(i),
      style: {
        textAlign: 'left',
        padding: '8px 10px',
        borderRadius: 'var(--radius-sm)',
        borderLeft: '2px solid',
        borderLeftColor: on ? 'var(--acid)' : 'var(--border)',
        background: on ? 'var(--acid-ghost)' : 'transparent',
        cursor: 'pointer',
        transition: 'all var(--dur-fast) var(--ease-out)'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: 'var(--font-display)',
        fontWeight: 500,
        fontSize: 'var(--text-sm)',
        color: on ? 'var(--acid)' : 'var(--bone)',
        letterSpacing: 'var(--track-wide)'
      }
    }, st.title), /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: 'var(--font-mono)',
        fontSize: 'var(--text-2xs)',
        color: 'var(--bone-faint)',
        marginTop: '2px'
      }
    }, st.era));
  }))), /*#__PURE__*/React.createElement("main", {
    className: "ax-grunge",
    style: {
      padding: 'var(--space-10) var(--space-8)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: '72ch',
      margin: '0 auto'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: 'var(--space-4)'
    }
  }, /*#__PURE__*/React.createElement(FactionTag, {
    faction: s.faction,
    size: "sm"
  }, s.attribution)), /*#__PURE__*/React.createElement(StoryHeader, {
    kicker: `${s.era} · ${s.attribution}`,
    title: s.title,
    subtitle: s.subtitle,
    faction: s.faction,
    style: {
      marginBottom: 'var(--space-6)'
    }
  }), /*#__PURE__*/React.createElement(Epigraph, {
    cite: s.cite,
    style: {
      marginBottom: 'var(--space-8)'
    }
  }, s.epigraph), /*#__PURE__*/React.createElement("div", {
    className: "ax-reading",
    style: {
      maxWidth: 'none'
    }
  }, s.body.map((para, i) => /*#__PURE__*/React.createElement("p", {
    key: i,
    style: i === 0 ? {
      marginTop: 0
    } : null
  }, i === 0 ? /*#__PURE__*/React.createElement("span", {
    style: {
      float: 'left',
      fontFamily: 'var(--font-display)',
      fontWeight: 600,
      fontSize: '3.4rem',
      lineHeight: 0.78,
      color: 'var(--acid)',
      margin: '4px 12px 0 0'
    }
  }, para.charAt(0)) : null, i === 0 ? para.slice(1) : para))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      marginTop: 'var(--space-8)',
      paddingTop: 'var(--space-5)',
      borderTop: '1px solid var(--border)'
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "ghost",
    disabled: idx === 0,
    onClick: () => setIdx(Math.max(0, idx - 1))
  }, "\u2190 Previous"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-2xs)',
      letterSpacing: 'var(--track-wide)',
      color: 'var(--bone-faint)'
    }
  }, String(idx + 1).padStart(2, '0'), " / ", String(stories.length).padStart(2, '0')), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    disabled: idx === stories.length - 1,
    icon: "\u2192",
    onClick: () => setIdx(Math.min(stories.length - 1, idx + 1))
  }, "Next")))));
}
window.ReaderScreen = ReaderScreen;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/companion_archive/Reader.jsx", error: String((e && e.message) || e) }); }

// ui_kits/companion_archive/Worlds.jsx
try { (() => {
/* Worlds.jsx — atmospheric profiles of the major settings. */
function WorldsScreen() {
  const {
    Panel,
    DataRow,
    Badge,
    GlitchTitle
  } = window.AscentUniverseDesignSystem_d01098;
  const worlds = [{
    name: 'Firsthome',
    faction: 'seeker',
    era: '~100,000 BCE',
    tag: 'Dyn homeworld',
    desc: 'A world tidally locked to a red dwarf. A habitable Dusk band separates the scorched Day from the frozen Night. Where Seeker first saw the stars.',
    rows: [['Star', 'Red dwarf'], ['Habitable', 'The Dusk band'], ['Native', 'The Dyn']]
  }, {
    name: 'Occupied Earth',
    faction: 'dyn',
    era: '2314–2479 CE',
    tag: 'A global prison',
    desc: 'Conurbation arcologies of twenty-two billion; single-person farms; the false-life wasteland creeping between cities. The Ascensor threads surface to firmament.',
    rows: [['Government', 'Arco (puppet)'], ['Hazard', 'The false life'], ['Link', 'The Ascensor']]
  }, {
    name: 'Kailash',
    faction: 'listener',
    era: '2937 CE',
    tag: 'The dying world',
    desc: 'An ancient Mars-like world on the fringe of a sterile galaxy. Rust plains, karst pits, ballistic arcs of matter. Twelve Other Moons hide in its Oort cloud.',
    rows: [['Star', 'Red giant'], ['Sky', 'Blue-black'], ['Cache', '12 Other Moons']]
  }, {
    name: 'The Interstice',
    faction: 'union',
    era: '2909 CE',
    tag: 'The chokepoint',
    desc: 'A wormhole at the trailing Lagrange of the gas giant Deliverance — the strategic gate between Arco and Union space. Site of the Atbarah attack and the Battle of Threshold.',
    rows: [['Type', 'Ancient wormhole'], ['Builders', 'The Others'], ['Battle', 'Threshold, 2909']]
  }];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--width-content)',
      margin: '0 auto',
      padding: 'var(--space-8) var(--space-6) var(--space-12)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: 'var(--space-3)',
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-2xs)',
      letterSpacing: 'var(--track-widest)',
      textTransform: 'uppercase',
      color: 'var(--arco)'
    }
  }, "\u25C9 Worlds & Eras"), /*#__PURE__*/React.createElement(GlitchTitle, {
    as: "h1",
    size: "lg",
    lowercase: false,
    style: {
      marginBottom: 'var(--space-8)'
    }
  }, "Worlds & Eras"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(2, 1fr)',
      gap: 'var(--space-4)'
    }
  }, worlds.map(w => /*#__PURE__*/React.createElement(Panel, {
    key: w.name,
    title: w.name,
    accent: `var(--${w.faction})`,
    badge: /*#__PURE__*/React.createElement(Badge, {
      status: "standby"
    }, w.era)
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-2xs)',
      letterSpacing: 'var(--track-wide)',
      textTransform: 'uppercase',
      color: `var(--${w.faction})`,
      marginBottom: 'var(--space-3)'
    }
  }, w.tag), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: 'var(--font-serif)',
      fontSize: 'var(--text-base)',
      lineHeight: 'var(--leading-reading)',
      color: 'var(--bone-soft)',
      marginBottom: 'var(--space-4)'
    }
  }, w.desc), w.rows.map((r, i) => /*#__PURE__*/React.createElement(DataRow, {
    key: r[0],
    label: r[0],
    value: r[1],
    last: i === w.rows.length - 1
  }))))));
}
window.WorldsScreen = WorldsScreen;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/companion_archive/Worlds.jsx", error: String((e && e.message) || e) }); }

// ui_kits/companion_archive/archiveData.js
try { (() => {
/* Ascent Universe — archive content (in-universe). Plain data, no framework. */
window.ARCHIVE = {
  navSections: [{
    label: 'Read',
    cards: [{
      kicker: 'READ · 18 STORIES',
      title: 'Stories',
      glyph: '▣',
      accent: 'var(--acid)',
      target: 'reader',
      desc: 'All fiction — eighteen works from ~100,000 BCE to ~3200 CE. Novels, short stories and interactive readers.'
    }, {
      kicker: 'MANUSCRIPTS',
      title: 'Drafts',
      glyph: '◫',
      accent: 'var(--bone-dim)',
      target: 'reader',
      desc: 'Second-draft manuscripts for Ascent and Eszel & The Listener. Chapter-by-chapter browsing.'
    }]
  }, {
    label: 'Explore',
    cards: [{
      kicker: 'CHRONOLOGY',
      title: 'Historical Timeline',
      glyph: '⟡',
      accent: 'var(--seeker)',
      target: 'codex',
      desc: 'From the Dyn deep past through the Battle of the Interstice to the Apathy War.'
    }, {
      kicker: 'INTELLIGENCE',
      title: 'Codex',
      glyph: '◈',
      accent: 'var(--chroma-red)',
      target: 'codex',
      desc: 'Classified dossiers on factions, personnel, vessels and threats. Arco, Union, the Dyn, the Strivers, the Apathy.'
    }, {
      kicker: 'WORLDS & ERAS',
      title: 'Worlds',
      glyph: '◉',
      accent: 'var(--arco)',
      target: 'codex',
      desc: 'From Firsthome to the Apathy War. Atmospheric profiles of the major settings and epochs.'
    }, {
      kicker: 'SCIENCE',
      title: 'Compendium',
      glyph: '✦',
      accent: 'var(--acid)',
      target: 'codex',
      desc: 'The real physics behind the fiction. ABC drives, Diamond Dusters, hyperdiamond armour, warseeds.'
    }]
  }, {
    label: 'Experience',
    cards: [{
      kicker: 'EXPERIENCE',
      title: 'The Anthropic Trap',
      glyph: '■',
      accent: 'var(--striver)',
      target: 'codex',
      wide: true,
      desc: 'You are almost certainly a simulation. The Apathy has run this scenario a million times. Do you surrender?'
    }, {
      kicker: 'DIPLOMATIC CHANNEL',
      title: 'Talk to the Utilitaria',
      glyph: '▷',
      accent: 'var(--utilitaria)',
      target: 'codex',
      desc: 'Open a channel with an Emissary. The collective will speaks through a singular vessel.'
    }, {
      kicker: 'IN-UNIVERSE TEXT',
      title: 'Reflections of Seeker',
      glyph: '◌',
      accent: 'var(--seeker)',
      target: 'reader',
      desc: '"All the worlds that were will always have been." The Dyn philosophical text.'
    }]
  }, {
    label: 'Simulate',
    cards: [{
      kicker: 'PLAYABLE RTS',
      title: 'Threshold: First Fleet',
      glyph: '⚔',
      accent: 'var(--union)',
      target: 'codex',
      wide: true,
      desc: 'Command Union\u2019s First Fleet at the Battle of Threshold, 2909 CE. Ten destroyer battlegroups against Arco warships at true scale. History records one kill. Beat it.'
    }, {
      kicker: 'PLAYABLE RTS',
      title: 'War of All Wars',
      glyph: '⚔',
      accent: 'var(--apathy)',
      target: 'codex',
      wide: true,
      desc: 'The Apathy approaches — an Earth-mass alien god at 40,000 G. Command A-spheres and D-spheres across light-minutes. Buy time for evacuation, or destroy it.'
    }]
  }],
  codex: [{
    id: 'annihilator',
    faction: 'arco',
    name: 'Annihilator-Class IPAV',
    kind: 'VESSEL',
    threat: 'CRITICAL',
    era: '2479 CE',
    summary: 'Arco\u2019s heaviest interplanetary assault vehicle. Spinal-mount Diamond Duster, hyperdiamond Whipple armour, antimatter beamed-core drive. One ship devastated Union\u2019s First Fleet at Threshold.',
    rows: [{
      label: 'Class',
      value: 'IP Assault Vehicle'
    }, {
      label: 'Drive',
      value: 'ABC · 0.12 c exhaust',
      tone: 'acid'
    }, {
      label: 'Primary',
      value: '500mm Diamond Duster'
    }, {
      label: 'Armour',
      value: 'Hyperdiamond Whipple'
    }, {
      label: 'Threat',
      value: 'CRITICAL',
      tone: 'alert'
    }],
    stats: [{
      label: 'Reactor output',
      value: 88
    }, {
      label: 'Armour rating',
      value: 94,
      color: 'var(--arco)'
    }, {
      label: 'Duster charge',
      value: 71,
      color: 'var(--acid)'
    }]
  }, {
    id: 'ktxl',
    faction: 'dyn',
    name: 'K\u2019txl — "Liar to Animals"',
    kind: 'PERSONNEL',
    threat: 'COOPERATIVE',
    era: '2310–3200 CE',
    summary: 'Female Dyn administrator. Initiated first contact at Tau Ceti, became Earth\u2019s Dynic administrator during the occupation, and is still referenced in the Apathy War. One of the few Dyn who transcends the species\u2019 amorality — she sounds almost human, with an inflection that is somehow off.',
    rows: [{
      label: 'Species',
      value: 'Dyn'
    }, {
      label: 'Role',
      value: 'Administrator / envoy'
    }, {
      label: 'First contact',
      value: 'Tau Ceti, 2310 CE',
      tone: 'info'
    }, {
      label: 'Status',
      value: 'Persistent across eras',
      tone: 'acid'
    }],
    stats: [{
      label: 'Diplomatic standing',
      value: 76,
      color: 'var(--dyn)'
    }, {
      label: 'Threat to humans',
      value: 22,
      color: 'var(--chroma-red)'
    }]
  }, {
    id: 'apathy',
    faction: 'apathy',
    name: 'The Apathy',
    kind: 'THREAT',
    threat: 'EXISTENTIAL',
    era: 'post-3000 CE',
    summary: 'Berserker machines of unknown origin — possibly spacetime defects. Earth-mass agglomerations decelerating at 40,000 G. They replicate by consuming mass, are practically indestructible, and deploy anti-mind affects and anthropic traps. Explaining their motives would pose "a risk to all that is conscious."',
    rows: [{
      label: 'Origin',
      value: 'Unknown'
    }, {
      label: 'Mass',
      value: '~1 Earth mass'
    }, {
      label: 'Deceleration',
      value: '40,000 G',
      tone: 'alert'
    }, {
      label: 'Weapon',
      value: 'Anti-mind affect; anthropic trap',
      tone: 'alert'
    }, {
      label: 'Threat',
      value: 'EXISTENTIAL',
      tone: 'alert'
    }],
    stats: [{
      label: 'Indestructibility',
      value: 98,
      color: 'var(--apathy)'
    }, {
      label: 'Comprehensibility',
      value: 6,
      color: 'var(--chroma-red)'
    }]
  }, {
    id: 'warseed',
    faction: 'utilitaria',
    name: 'Warseeds',
    kind: 'WEAPON SYSTEM',
    threat: 'DORMANT',
    era: '2314 / 2479 CE',
    summary: 'The dying Utilitaria\u2019s final contingency: tens of thousands of geothermal hubs across Earth\u2019s ocean floors, each unspooling hyperdiamond optical fibres to the surface, each delivering 100 kW of coherent blue light. Together they set the sky on fire and burned the Dyn fleet to ash. The Dragon\u2019s Tooth is their symbol.',
    rows: [{
      label: 'Origin',
      value: 'The Utilitaria'
    }, {
      label: 'Hubs',
      value: 'Tens of thousands'
    }, {
      label: 'Output',
      value: '100 kW coherent blue / fibre',
      tone: 'acid'
    }, {
      label: 'Activated',
      value: '2479 CE — Liberation',
      tone: 'acid'
    }],
    stats: [{
      label: 'Coverage',
      value: 91,
      color: 'var(--acid)'
    }, {
      label: 'Charge',
      value: 100,
      color: 'var(--acid)'
    }]
  }],
  stories: [{
    id: 'ascent',
    title: 'Ascent',
    era: '2479 CE',
    attribution: 'HUMAN',
    faction: 'dyn',
    subtitle: 'Occupied Earth — the Hollow Tower, the wasteland, the deep',
    epigraph: 'All the worlds that were will always have been.',
    cite: 'The Reflections of Seeker',
    body: ['Jan, a starving wastelander on occupied Earth, is caught stealing food and taken in by a resistance cell that operates under the symbol of a serrated tooth — the Dragon\u2019s Tooth, connected to the Utilitaria\u2019s hidden warseed programme.', 'He carries a photograph of his daughter Eva, abducted by unknown forces. It is his sole motivation. A captive Dyn aboard the crawler offers a deal: free it, and it will lead him to her. The two beings, from utterly different species and trusting nothing, are bound by mutual necessity.', 'Far above, Vash governs from the Hollow Tower as Arco\u2019s Ambassador — the most powerful human on Earth, and wholly subordinate to the Dyn. He has spent his life inflicting the lesser evil. When the warseeds finally fire, the sky burns and the Dyn flare and wink out. Corbin claims the credit. The age of Ascent begins, built on lies.']
  }, {
    id: 'listener',
    title: 'Eszel & The Listener',
    era: '2909–2937 CE',
    attribution: 'HUMAN · AI-EDITED',
    faction: 'listener',
    subtitle: 'The Battle of Threshold and the Kailash expedition',
    epigraph: 'I am everything, it said. And for once, that was not a lie.',
    cite: 'The Listener',
    body: ['Walker Base — two hundred personnel — is annihilated, transmuted into a thin slurry by a localised region of extreme gravity. A sole survivor is found eight hundred kilometres away: Eszel, an eighteen-year-old civilian, and a masterful liar.', 'She alone can communicate with the Listener — a being who appears as a blandly handsome young man in a grey suit, floating off the ground, who has been nudging her since childhood. He claims to be everything: the space between the stars and the ground beneath her feet.', 'In the inner Oort cloud hide twelve Other Moons — the greatest treasure trove of technology in all history. With one, the ancient Dyn broke the Utilitaria. With ten, there would be no limits to our power.']
  }, {
    id: 'warofallwars',
    title: 'The War of All Wars',
    era: '~3200 CE',
    attribution: 'HUMAN',
    faction: 'apathy',
    subtitle: 'The first decisive victory against the Apathy',
    epigraph: 'Anthropic traps are to be ignored.',
    cite: 'Fleet engagement protocol',
    body: ['The Apathy deploys an unprecedented weapon: a holographic proof that it has simulated the human crews millions of times. Only one in a million is real. If they surrender, all copies will live.', 'The crew refuses, per protocol. Former enemies fight side by side now — Arco, Union, the Dyn, the Multiplicity, rational Blights. The Utilitaria directs the war but uses limited-intelligence pilots, lest its full nodes be exposed to assimilation.', 'The Apathy states, cryptically, that explaining its motives would pose a risk to all that is conscious. Its nature remains the universe\u2019s deepest mystery.']
  }]
};
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/companion_archive/archiveData.js", error: String((e && e.message) || e) }); }

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.FactionTag = __ds_scope.FactionTag;

__ds_ns.GlitchTitle = __ds_scope.GlitchTitle;

__ds_ns.DataRow = __ds_scope.DataRow;

__ds_ns.Panel = __ds_scope.Panel;

__ds_ns.StatBar = __ds_scope.StatBar;

__ds_ns.NavCard = __ds_scope.NavCard;

__ds_ns.SectionLabel = __ds_scope.SectionLabel;

__ds_ns.Epigraph = __ds_scope.Epigraph;

__ds_ns.StoryHeader = __ds_scope.StoryHeader;

})();
