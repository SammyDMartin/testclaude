import { ReactNode, CSSProperties } from 'react';

export interface BadgeProps {
  children?: ReactNode;
  /** Status colour language. @default "nominal" */
  status?: 'nominal' | 'armed' | 'alert' | 'standby' | 'info' | 'classified';
  /** Filled instead of outlined. @default false */
  solid?: boolean;
  style?: CSSProperties;
}

/**
 * A small status / classification stamp — mono, uppercase, outlined.
 * Use for telemetry states, clearance levels and dossier tags.
 */
export function Badge(props: BadgeProps): JSX.Element;
