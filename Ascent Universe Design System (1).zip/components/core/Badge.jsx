import React from 'react';

/**
 * Badge — a small status / classification stamp.
 * Outlined, mono, uppercase. Reads as telemetry or a clearance label.
 */
export function Badge({ children, status = 'nominal', solid = false, style = {}, ...rest }) {
  const map = {
    nominal: 'var(--status-nominal)',
    armed: 'var(--status-armed)',
    alert: 'var(--status-alert)',
    standby: 'var(--status-standby)',
    info: 'var(--info)',
    classified: 'var(--chroma-red)',
  };
  const c = map[status] || map.nominal;

  const base = {
    display: 'inline-flex',
    alignItems: 'center',
    gap: '6px',
    fontFamily: 'var(--font-mono)',
    fontSize: 'var(--text-2xs)',
    fontWeight: 'var(--weight-medium)',
    letterSpacing: 'var(--track-wider)',
    textTransform: 'uppercase',
    padding: '3px 8px',
    borderRadius: 'var(--radius-sm)',
    border: '1px solid',
    lineHeight: 1.4,
    ...(solid
      ? { background: c, color: 'var(--on-accent)', borderColor: c }
      : { background: 'transparent', color: c, borderColor: c }),
    ...style,
  };

  return (
    <span style={base} {...rest}>
      {status === 'alert' || status === 'classified' ? (
        <span aria-hidden="true" style={{
          width: '5px', height: '5px', borderRadius: '50%',
          background: solid ? 'var(--on-accent)' : c,
        }} />
      ) : null}
      {children}
    </span>
  );
}
