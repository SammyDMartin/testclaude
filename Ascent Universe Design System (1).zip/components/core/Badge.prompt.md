Status / classification stamp — mono uppercase pill for telemetry states, clearance levels and dossier tags.

```jsx
<Badge status="nominal">Nominal</Badge>
<Badge status="armed">Armed</Badge>
<Badge status="alert">Critical</Badge>
<Badge status="classified" solid>Classified</Badge>
```

`status`: `nominal` (acid), `armed` (Arco amber), `alert` (chroma-red, gets a dot), `standby` (dim bone), `info` (cyan), `classified` (red, dot). `solid` fills the badge instead of outlining it. Keep the label to one or two words.
