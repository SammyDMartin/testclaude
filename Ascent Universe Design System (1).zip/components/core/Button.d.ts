import { ReactNode, CSSProperties } from 'react';

/**
 * @startingPoint section="Core" subtitle="Command-line styled action button" viewport="700x200"
 */
export interface ButtonProps {
  children?: ReactNode;
  /** Visual weight. @default "primary" */
  variant?: 'primary' | 'secondary' | 'ghost' | 'danger';
  /** @default "md" */
  size?: 'sm' | 'md' | 'lg';
  disabled?: boolean;
  /** Stretch to fill the container width. */
  block?: boolean;
  /** Leading glyph (unicode char or node) — keep it sparse. */
  icon?: ReactNode;
  /** Render as an anchor instead of a button. */
  href?: string;
  onClick?: (e: any) => void;
  type?: 'button' | 'submit' | 'reset';
  style?: CSSProperties;
}

/**
 * The primary action control for the Ascent archive. Mono, uppercase and
 * wide-tracked so it reads like a command line, not a marketing CTA.
 * @startingPoint section="Core" subtitle="Command-line styled action button" viewport="700x200"
 */
export function Button(props: ButtonProps): JSX.Element;
