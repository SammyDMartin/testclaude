import React, { useState } from 'react';

/**
 * Button — the primary action control.
 * Mono, uppercase, wide-tracked: it reads like a command, not a web button.
 */
export function Button({
  children,
  variant = 'primary',
  size = 'md',
  disabled = false,
  block = false,
  icon = null,
  href,
  onClick,
  type = 'button',
  style = {},
  ...rest
}) {
  const [hover, setHover] = useState(false);
  const [active, setActive] = useState(false);

  const sizes = {
    sm: { padding: '6px 12px', fontSize: 'var(--text-2xs)' },
    md: { padding: '9px 18px', fontSize: 'var(--text-xs)' },
    lg: { padding: '13px 26px', fontSize: 'var(--text-sm)' },
  };
  const s = sizes[size] || sizes.md;

  const palette = {
    primary: {
      base: { background: 'var(--acid)', color: 'var(--on-accent)', borderColor: 'var(--acid)' },
      hover: { background: 'var(--acid-bright)', borderColor: 'var(--acid-bright)', boxShadow: 'var(--glow-acid-strong)' },
      active: { background: 'var(--acid-deep)', borderColor: 'var(--acid-deep)' },
    },
    secondary: {
      base: { background: 'transparent', color: 'var(--bone)', borderColor: 'var(--border-strong)' },
      hover: { color: 'var(--acid)', borderColor: 'var(--acid)' },
      active: { background: 'var(--acid-ghost)' },
    },
    ghost: {
      base: { background: 'transparent', color: 'var(--bone-dim)', borderColor: 'transparent' },
      hover: { color: 'var(--acid)' },
      active: { color: 'var(--acid-deep)' },
    },
    danger: {
      base: { background: 'transparent', color: 'var(--chroma-red)', borderColor: 'var(--chroma-red)' },
      hover: { background: 'var(--chroma-red)', color: 'var(--bone)', boxShadow: 'var(--glow-red)' },
      active: { background: 'var(--chroma-red)' },
    },
  };
  const p = palette[variant] || palette.primary;

  const computed = {
    fontFamily: 'var(--font-mono)',
    fontWeight: 'var(--weight-medium)',
    fontSize: s.fontSize,
    letterSpacing: 'var(--track-wider)',
    textTransform: 'uppercase',
    padding: s.padding,
    borderRadius: 'var(--radius-sm)',
    border: '1px solid',
    cursor: disabled ? 'not-allowed' : 'pointer',
    transition: 'all var(--dur-fast) var(--ease-out)',
    display: block ? 'flex' : 'inline-flex',
    width: block ? '100%' : undefined,
    alignItems: 'center',
    justifyContent: 'center',
    gap: '8px',
    whiteSpace: 'nowrap',
    opacity: disabled ? 0.35 : 1,
    transform: active && !disabled ? 'translateY(1px)' : 'none',
    ...p.base,
    ...(hover && !disabled ? p.hover : null),
    ...(active && !disabled ? p.active : null),
    ...style,
  };

  const handlers = disabled ? {} : {
    onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => { setHover(false); setActive(false); },
    onMouseDown: () => setActive(true),
    onMouseUp: () => setActive(false),
  };

  const content = (
    <>
      {icon ? <span aria-hidden="true" style={{ fontSize: '1.1em', lineHeight: 0 }}>{icon}</span> : null}
      {children}
    </>
  );

  if (href && !disabled) {
    return <a href={href} style={computed} {...handlers} {...rest}>{content}</a>;
  }
  return (
    <button type={type} disabled={disabled} style={computed} {...handlers} {...rest}>
      {content}
    </button>
  );
}
