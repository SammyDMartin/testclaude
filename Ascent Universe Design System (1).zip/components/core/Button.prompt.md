Command-styled action button — mono, uppercase, wide-tracked; use for any primary or secondary action in the archive.

```jsx
<Button variant="primary" size="md" onClick={fire}>Activate Warseeds</Button>
<Button variant="secondary" icon="→">Open Dossier</Button>
<Button variant="ghost" size="sm">Dismiss</Button>
<Button variant="danger">Purge Node</Button>
```

Variants: `primary` (acid fill, the one true CTA), `secondary` (hairline outline → acid on hover), `ghost` (text only), `danger` (chroma-red, for destructive/alert actions). Sizes `sm | md | lg`. Pass `href` to render as a link, `block` to fill width, `icon` for a sparse leading glyph. Hover/press states are built in.
