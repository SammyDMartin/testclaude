import { ReactNode, CSSProperties } from 'react';

export interface FactionTagProps {
  /** Which polity / entity. @default "arco" */
  faction?: 'arco' | 'union' | 'dyn' | 'striver' | 'apathy' | 'utilitaria' | 'listener' | 'seeker';
  /** Override the default label. */
  children?: ReactNode;
  /** @default "md" */
  size?: 'sm' | 'md';
  style?: CSSProperties;
}

/**
 * Colour-coded entity marker (diamond + name) for the codex, character
 * threads and dossiers. Each faction has a fixed hue from the palette.
 */
export function FactionTag(props: FactionTagProps): JSX.Element;
