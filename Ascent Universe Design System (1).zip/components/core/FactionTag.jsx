import React from 'react';

const FACTIONS = {
  arco:       { color: 'var(--arco)',       label: 'Arco' },
  union:      { color: 'var(--union)',      label: 'Union' },
  dyn:        { color: 'var(--dyn)',        label: 'The Dyn' },
  striver:    { color: 'var(--striver)',    label: 'Strivers' },
  apathy:     { color: 'var(--apathy)',     label: 'The Apathy' },
  utilitaria: { color: 'var(--utilitaria)', label: 'Utilitaria' },
  listener:   { color: 'var(--listener)',   label: 'The Listener' },
  seeker:     { color: 'var(--seeker)',     label: 'Seeker' },
};

/**
 * FactionTag — a colour-coded entity marker for the codex, threads & dossiers.
 * A small diamond in the faction hue + its name (override with children).
 */
export function FactionTag({ faction = 'arco', children, size = 'md', style = {}, ...rest }) {
  const f = FACTIONS[faction] || FACTIONS.arco;
  const fs = size === 'sm' ? 'var(--text-2xs)' : 'var(--text-xs)';
  const d = size === 'sm' ? 7 : 9;

  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center', gap: '7px',
      fontFamily: 'var(--font-mono)', fontSize: fs,
      letterSpacing: 'var(--track-wide)', textTransform: 'uppercase',
      color: 'var(--bone)', ...style,
    }} {...rest}>
      <span aria-hidden="true" style={{
        width: `${d}px`, height: `${d}px`, background: f.color, flex: 'none',
        clipPath: 'polygon(50% 0%, 100% 50%, 50% 100%, 0% 50%)',
        boxShadow: `0 0 8px ${f.color}`,
      }} />
      {children || f.label}
    </span>
  );
}
