Colour-coded entity marker — a glowing diamond in the faction hue plus its name. Use across the codex, character threads and dossier headers so a polity always reads the same colour.

```jsx
<FactionTag faction="dyn" />
<FactionTag faction="arco">Arco · Annihilator</FactionTag>
<FactionTag faction="apathy" size="sm" />
```

`faction`: `arco | union | dyn | striver | apathy | utilitaria | listener | seeker`. Pass `children` to override the default label (e.g. a specific ship or character). `size` `sm | md`.
