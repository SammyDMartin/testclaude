import { ReactNode, CSSProperties, ElementType } from 'react';

/**
 * @startingPoint section="Core" subtitle="Chromatic-aberration display title" viewport="700x220"
 */
export interface GlitchTitleProps {
  children?: ReactNode;
  /** Heading tag/element to render. @default "h2" */
  as?: ElementType;
  /** @default "xl" */
  size?: 'sm' | 'md' | 'lg' | 'xl' | 'hero';
  /** Display weight (Chakra Petch). @default 300 */
  weight?: 300 | 400 | 500 | 600 | 700;
  /** Force lowercase, as on the cover wordmark. @default true */
  lowercase?: boolean;
  /** Widen the chromatic offset on hover. @default true */
  intensify?: boolean;
  style?: CSSProperties;
}

/**
 * The signature title treatment: display type with the cover's red/cyan
 * chromatic-aberration offset. Use for the wordmark and feature headings.
 * @startingPoint section="Core" subtitle="Chromatic-aberration display title" viewport="700x220"
 */
export function GlitchTitle(props: GlitchTitleProps): JSX.Element;
