import React, { useState } from 'react';

/**
 * GlitchTitle — text with the cover's red/cyan chromatic-aberration treatment.
 * The signature title style of the universe. Optionally intensifies on hover.
 */
export function GlitchTitle({
  children,
  as: Tag = 'h2',
  size = 'xl',
  weight = 300,
  lowercase = true,
  intensify = true,
  style = {},
  ...rest
}) {
  const [hover, setHover] = useState(false);

  const sizes = {
    sm: 'var(--text-lg)',
    md: 'var(--text-xl)',
    lg: 'var(--text-2xl)',
    xl: 'var(--text-3xl)',
    hero: 'var(--text-hero)',
  };

  const offset = hover && intensify ? '0.07em' : '0.045em';
  const computed = {
    fontFamily: 'var(--font-display)',
    fontWeight: weight,
    fontSize: sizes[size] || sizes.xl,
    lineHeight: 'var(--leading-tight)',
    letterSpacing: 'var(--track-widest)',
    textTransform: lowercase ? 'lowercase' : 'none',
    color: 'var(--bone)',
    textShadow: `${offset} 0 var(--chroma-red), -${offset} 0 var(--chroma-cyan)`,
    transition: 'text-shadow var(--dur) var(--ease-out)',
    margin: 0,
    ...style,
  };

  return (
    <Tag
      style={computed}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      {...rest}
    >
      {children}
    </Tag>
  );
}
