The universe's signature title — display type with the cover's red/cyan chromatic-aberration offset. Use for the wordmark and major feature headings, sparingly.

```jsx
<GlitchTitle as="h1" size="hero">ascent</GlitchTitle>
<GlitchTitle size="lg" lowercase={false}>The Anthropic Trap</GlitchTitle>
```

`size`: `sm | md | lg | xl | hero`. `weight` 300 (default, matches the cover) → 700. `lowercase` defaults true (the wordmark is lowercase). `intensify` widens the offset on hover. Don't stack two on one screen — it's a focal treatment.
