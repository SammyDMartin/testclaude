import { ReactNode, CSSProperties } from 'react';

export interface DataRowProps {
  label: ReactNode;
  value: ReactNode;
  /** Optional second line under the value. */
  sub?: ReactNode;
  /** Value colour. @default "default" */
  tone?: 'default' | 'acid' | 'alert' | 'info' | 'dim' | 'warn';
  /** Drop the bottom hairline (last row in a group). */
  last?: boolean;
  style?: CSSProperties;
}

/** A single label/value spec line for dossiers and stat sheets (mono). */
export function DataRow(props: DataRowProps): JSX.Element;
