import React from 'react';

/**
 * DataRow — a single label/value line for dossiers and spec sheets.
 * Mono, hairline-separated, with an optional sub-line and value tone.
 */
export function DataRow({ label, value, sub, tone = 'default', last = false, style = {}, ...rest }) {
  const tones = {
    default: 'var(--bone)',
    acid: 'var(--acid)',
    alert: 'var(--chroma-red)',
    info: 'var(--info)',
    dim: 'var(--bone-dim)',
    warn: 'var(--arco)',
  };
  return (
    <div style={{
      display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', gap: 'var(--space-4)',
      padding: '6px 0',
      borderBottom: last ? 'none' : '1px solid var(--bone-hair)',
      fontFamily: 'var(--font-mono)',
      ...style,
    }} {...rest}>
      <span style={{
        fontSize: 'var(--text-xs)', color: 'var(--bone-faint)',
        letterSpacing: 'var(--track-wide)', textTransform: 'uppercase', flex: 'none', maxWidth: '46%',
      }}>{label}</span>
      <span style={{ textAlign: 'right', minWidth: 0 }}>
        <span style={{ fontSize: 'var(--text-xs)', color: tones[tone] || tones.default, letterSpacing: '0.02em' }}>{value}</span>
        {sub != null ? (
          <span style={{ display: 'block', fontSize: 'var(--text-2xs)', color: 'var(--bone-ghost)', marginTop: '2px' }}>{sub}</span>
        ) : null}
      </span>
    </div>
  );
}
