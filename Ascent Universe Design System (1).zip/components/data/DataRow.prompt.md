A single label/value spec line for dossiers, mono and hairline-separated.

```jsx
<DataRow label="Drive" value="ABC · 0.12 c" tone="acid" />
<DataRow label="Threat" value="Critical" tone="alert" />
<DataRow label="Epoch" value="2479 CE" sub="Dynic occupation" last />
```

Place inside a `Panel`. Tones: `default | acid | alert | info | dim | warn`. `sub` adds a faint second line; `last` drops the bottom hairline.
