import { ReactNode, CSSProperties } from 'react';

/**
 * @startingPoint section="Data" subtitle="Dossier / telemetry panel" viewport="700x300"
 */
export interface PanelProps {
  /** Header title (omit for a plain bordered surface). */
  title?: ReactNode;
  /** Right-aligned header slot — typically a <Badge/>. */
  badge?: ReactNode;
  /** Accent colour of the title tick. @default acid */
  accent?: string;
  children?: ReactNode;
  style?: CSSProperties;
  bodyStyle?: CSSProperties;
}

/**
 * The core dossier / telemetry surface: a hairline-bordered card with an
 * optional titled header (tick + label + right slot) and a padded body.
 * @startingPoint section="Data" subtitle="Dossier / telemetry panel" viewport="700x300"
 */
export function Panel(props: PanelProps): JSX.Element;
