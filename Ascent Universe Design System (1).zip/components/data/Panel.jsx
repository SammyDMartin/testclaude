import React from 'react';

/**
 * Panel — the core dossier / telemetry surface.
 * Hairline-bordered card with an optional titled header and a right slot.
 */
export function Panel({ title, badge, accent = 'var(--acid)', children, style = {}, bodyStyle = {}, ...rest }) {
  return (
    <section style={{
      background: 'var(--surface)',
      border: '1px solid var(--border)',
      borderRadius: 'var(--radius-md)',
      boxShadow: 'var(--shadow-panel)',
      overflow: 'hidden',
      ...style,
    }} {...rest}>
      {title != null && (
        <header style={{
          display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 'var(--space-3)',
          padding: 'var(--space-3) var(--space-4)',
          borderBottom: '1px solid var(--border)',
        }}>
          <span style={{
            display: 'inline-flex', alignItems: 'center', gap: '10px',
            fontFamily: 'var(--font-display)', fontSize: 'var(--text-sm)',
            fontWeight: 'var(--weight-semibold)', letterSpacing: 'var(--track-wider)',
            textTransform: 'uppercase', color: 'var(--bone)',
          }}>
            <span aria-hidden="true" style={{ width: '3px', height: '13px', background: accent, display: 'inline-block' }} />
            {title}
          </span>
          {badge != null ? <span style={{ flex: 'none' }}>{badge}</span> : null}
        </header>
      )}
      <div style={{ padding: 'var(--space-4)', ...bodyStyle }}>{children}</div>
    </section>
  );
}
