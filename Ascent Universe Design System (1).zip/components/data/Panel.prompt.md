Dossier & telemetry surfaces. `Panel` is the bordered card; `DataRow` and `StatBar` go inside it.

```jsx
<Panel title="Annihilator-Class IPAV" badge={<Badge status="alert">Critical</Badge>}>
  <DataRow label="Drive" value="ABC · 0.12 c" tone="acid" />
  <DataRow label="Armour" value="Hyperdiamond Whipple" />
  <DataRow label="Epoch" value="2479 CE" sub="Dynic occupation" last />
  <StatBar label="Reactor" value={82} color="var(--acid)" style={{ marginTop: 16 }} />
  <StatBar label="Hull integrity" value={34} color="var(--chroma-red)" style={{ marginTop: 12 }} />
</Panel>
```

`Panel` takes `title`, a right-slot `badge`, and `accent` (the title tick colour). `DataRow` tones: `default | acid | alert | info | dim | warn`; set `last` to drop its hairline. `StatBar` clamps `value/max` to a 0–100% glowing fill.
