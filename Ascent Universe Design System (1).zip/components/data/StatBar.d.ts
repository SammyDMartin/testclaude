import { ReactNode, CSSProperties } from 'react';

export interface StatBarProps {
  label: ReactNode;
  /** Current value. @default 0 */
  value?: number;
  /** @default 100 */
  max?: number;
  /** Fill colour. @default acid */
  color?: string;
  /** Unit appended to the value. @default "%" */
  unit?: string;
  showValue?: boolean;
  style?: CSSProperties;
}

/** A labelled telemetry meter: thin track + glowing acid fill. */
export function StatBar(props: StatBarProps): JSX.Element;
