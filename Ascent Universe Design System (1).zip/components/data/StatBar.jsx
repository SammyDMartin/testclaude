import React from 'react';

/**
 * StatBar — a labelled telemetry meter (power, integrity, charge…).
 * Thin track + animated acid fill, with a mono header row.
 */
export function StatBar({ label, value = 0, max = 100, color = 'var(--acid)', unit = '%', showValue = true, style = {}, ...rest }) {
  const pct = Math.max(0, Math.min(100, (value / max) * 100));
  return (
    <div style={{ ...style }} {...rest}>
      <div style={{
        display: 'flex', justifyContent: 'space-between',
        fontFamily: 'var(--font-mono)', fontSize: 'var(--text-2xs)',
        letterSpacing: 'var(--track-wide)', textTransform: 'uppercase',
        color: 'var(--bone-faint)', marginBottom: '5px',
      }}>
        <span>{label}</span>
        {showValue ? <span style={{ color }}>{Math.round(value)}{unit}</span> : null}
      </div>
      <div style={{ height: '4px', background: 'var(--bone-hair)', borderRadius: 'var(--radius-pill)', overflow: 'hidden' }}>
        <div style={{
          height: '100%', width: `${pct}%`, background: color,
          borderRadius: 'var(--radius-pill)',
          boxShadow: `0 0 10px ${color}`,
          transition: 'width var(--dur-slow) var(--ease-out)',
        }} />
      </div>
    </div>
  );
}
