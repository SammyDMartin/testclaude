A labelled telemetry meter — thin track with a glowing fill. For power, integrity, charge, evacuation progress, etc.

```jsx
<StatBar label="Reactor" value={82} />
<StatBar label="Hull integrity" value={34} color="var(--chroma-red)" />
<StatBar label="Evac" value={1840} max={2200} unit=" souls" showValue />
```

`value/max` clamp to 0–100% of the track width; `color` sets the fill (defaults to acid); `unit` is appended to the readout; `showValue={false}` hides the number.
