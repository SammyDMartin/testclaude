import { ReactNode, CSSProperties } from 'react';

/**
 * @startingPoint section="Navigation" subtitle="Hub navigation tile" viewport="700x220"
 */
export interface NavCardProps {
  /** Mono classification kicker above the title, e.g. "READ · 18 STORIES". */
  kicker?: ReactNode;
  title: ReactNode;
  children?: ReactNode;
  href?: string;
  /** Left-rail accent colour (faction or acid). @default acid */
  accent?: string;
  /** Optional single glyph in the top-right. */
  glyph?: ReactNode;
  /** File index — rendered as a large faint watermark (e.g. 1 → "01"). */
  index?: number;
  /** Span the full grid width. */
  wide?: boolean;
  style?: CSSProperties;
}

/**
 * The hub navigation tile: classification kicker, display title, description
 * and arrow. Hover lifts it, lights the acid edge and nudges the title's
 * chromatic offset.
 * @startingPoint section="Navigation" subtitle="Hub navigation tile" viewport="700x220"
 */
export function NavCard(props: NavCardProps): JSX.Element;
