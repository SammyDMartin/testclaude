import React, { useState } from 'react';

/**
 * NavCard — the hub navigation tile, styled as a dossier / targeting reticle:
 * corner brackets and a faint file index instead of a plain bordered box.
 * A classification kicker, a display title, a description and an arrow.
 * Hover washes the cell, lights the brackets and nudges the chromatic title.
 */
export function NavCard({
  kicker,
  title,
  children,
  href = '#',
  accent = 'var(--acid)',
  glyph,
  index,
  wide = false,
  style = {},
  ...rest
}) {
  const [hover, setHover] = useState(false);
  const bracketColor = hover ? accent : 'var(--border-strong)';
  const b = 'var(--space-3)'; // bracket inset
  const corner = (pos) => {
    const size = 13, t = 1.5;
    const base = { position: 'absolute', width: `${size}px`, height: `${size}px`, transition: 'border-color var(--dur) var(--ease-out), opacity var(--dur) var(--ease-out)', pointerEvents: 'none', opacity: hover ? 1 : 0.7 };
    const e = { ...base };
    if (pos.includes('t')) { e.top = b; e.borderTop = `${t}px solid ${bracketColor}`; }
    if (pos.includes('b')) { e.bottom = b; e.borderBottom = `${t}px solid ${bracketColor}`; }
    if (pos.includes('l')) { e.left = b; e.borderLeft = `${t}px solid ${bracketColor}`; }
    if (pos.includes('r')) { e.right = b; e.borderRight = `${t}px solid ${bracketColor}`; }
    return <span key={pos} aria-hidden="true" style={e} />;
  };

  return (
    <a
      href={href}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      style={{
        position: 'relative',
        display: 'block',
        gridColumn: wide ? '1 / -1' : undefined,
        padding: 'var(--space-5) var(--space-6)',
        textDecoration: 'none',
        background: hover ? 'var(--acid-ghost)' : 'transparent',
        boxShadow: hover ? 'var(--glow-acid)' : 'none',
        transition: 'background var(--dur) var(--ease-out), box-shadow var(--dur) var(--ease-out)',
        overflow: 'hidden',
        ...style,
      }}
      {...rest}
    >
      {['tl', 'tr', 'bl', 'br'].map(corner)}

      {/* faint file index watermark */}
      {index != null && (
        <span aria-hidden="true" style={{
          position: 'absolute', right: 'var(--space-5)', top: 'var(--space-3)',
          fontFamily: 'var(--font-mono)', fontWeight: 700, fontSize: '2.8rem', lineHeight: 1,
          color: hover ? 'rgba(200,224,33,0.14)' : 'var(--bone-hair)',
          letterSpacing: '-0.04em', transition: 'color var(--dur) var(--ease-out)', userSelect: 'none',
        }}>{String(index).padStart(2, '0')}</span>
      )}

      {/* kicker line: diamond mark + classification + optional glyph */}
      <div style={{ display: 'flex', alignItems: 'center', gap: '9px', marginBottom: 'var(--space-3)', position: 'relative', zIndex: 1 }}>
        <span aria-hidden="true" style={{
          width: '7px', height: '7px', flex: 'none', background: accent,
          clipPath: 'polygon(50% 0%, 100% 50%, 50% 100%, 0% 50%)',
          boxShadow: hover ? `0 0 8px ${accent}` : 'none', transition: 'box-shadow var(--dur) var(--ease-out)',
        }} />
        <span style={{
          fontFamily: 'var(--font-mono)', fontSize: 'var(--text-2xs)',
          letterSpacing: 'var(--track-wider)', textTransform: 'uppercase',
          color: hover ? 'var(--acid)' : 'var(--bone-faint)',
          transition: 'color var(--dur) var(--ease-out)',
        }}>{kicker}</span>
        {glyph ? <span aria-hidden="true" style={{ fontSize: 'var(--text-base)', color: accent, lineHeight: 1, marginLeft: '2px' }}>{glyph}</span> : null}
      </div>

      <div style={{
        fontFamily: 'var(--font-display)', fontWeight: 'var(--weight-semibold)',
        fontSize: 'var(--text-lg)', letterSpacing: 'var(--track-wide)',
        color: 'var(--bone)', marginBottom: 'var(--space-2)', position: 'relative', zIndex: 1,
        textShadow: hover ? '0.03em 0 var(--chroma-red), -0.03em 0 var(--chroma-cyan)' : 'none',
        transition: 'text-shadow var(--dur) var(--ease-out)',
      }}>{title}</div>

      <div style={{
        fontFamily: 'var(--font-sans)', fontSize: 'var(--text-sm)',
        lineHeight: 'var(--leading-normal)', color: 'var(--bone-dim)',
        maxWidth: '54ch', position: 'relative', zIndex: 1, paddingRight: 'var(--space-5)',
      }}>{children}</div>

      <span aria-hidden="true" style={{
        position: 'absolute', right: 'var(--space-5)', bottom: 'var(--space-4)',
        color: hover ? 'var(--acid)' : 'var(--bone-faint)',
        fontFamily: 'var(--font-mono)', fontSize: 'var(--text-lg)',
        transform: `translateX(${hover ? '3px' : '0'})`,
        transition: 'all var(--dur) var(--ease-out)', zIndex: 1,
      }}>→</span>
    </a>
  );
}
