The hub navigation tile — styled as a dossier / targeting reticle: corner brackets and a faint file index instead of a plain box. Classification kicker, display title, description, arrow.

```jsx
<NavCard kicker="READ · 18 STORIES" title="Stories" index={1}
  glyph="▣" href="stories.html">
  All fiction from ~100,000 BCE to ~3200 CE. Novels, short stories and interactive readers.
</NavCard>
<NavCard kicker="EXPERIENCE" title="The Anthropic Trap" accent="var(--striver)" index={6} wide>…</NavCard>
```

Hover washes the cell with acid-ghost, lights the corner brackets + diamond, and nudges the title's chromatic offset. `accent` sets the brackets/diamond (use a faction colour to theme it); `glyph` is one optional unicode mark; `index` prints a large faint file number; `wide` spans the full grid width. Lay cards out in a 2-col `display:grid; gap: var(--space-4)`.
