import { ReactNode, CSSProperties } from 'react';

export interface SectionLabelProps {
  children?: ReactNode;
  /** Tick colour. @default acid */
  accent?: string;
  style?: CSSProperties;
}

/** A section header: small mono label above a hairline rule with an acid tick. */
export function SectionLabel(props: SectionLabelProps): JSX.Element;
