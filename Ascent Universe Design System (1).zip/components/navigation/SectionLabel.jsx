import React from 'react';

/**
 * SectionLabel — a hub/section header: a small mono label above a hairline
 * rule with an acid tick. The organising device of the archive.
 */
export function SectionLabel({ children, accent = 'var(--acid)', style = {}, ...rest }) {
  return (
    <div style={{ ...style }} {...rest}>
      <div style={{
        fontFamily: 'var(--font-mono)', fontSize: 'var(--text-2xs)',
        letterSpacing: 'var(--track-widest)', textTransform: 'uppercase',
        color: 'var(--bone-dim)', marginBottom: 'var(--space-2)',
      }}>{children}</div>
      <div style={{ position: 'relative', height: '1px', background: 'var(--border)' }}>
        <span aria-hidden="true" style={{
          position: 'absolute', left: 0, top: 0, width: '40px', height: '1px', background: accent,
        }} />
      </div>
    </div>
  );
}
