Section header — a small mono label over a hairline rule with an acid tick. Use to group the home grid (READ / EXPLORE / EXPERIENCE / SIMULATE) and any list page.

```jsx
<SectionLabel>Explore</SectionLabel>
<SectionLabel accent="var(--striver)">Simulate</SectionLabel>
```

Pair above a grid of `NavCard`s. `accent` recolours the tick.
