import { ReactNode, CSSProperties } from 'react';

export interface EpigraphProps {
  children?: ReactNode;
  /** Attribution shown after an em-dash. */
  cite?: ReactNode;
  /** @default "left" */
  align?: 'left' | 'center';
  style?: CSSProperties;
}

/**
 * Chapter epigraph — italic serif quote with an em-dashed attribution and an
 * acid left rule. The literary voice device of the universe.
 */
export function Epigraph(props: EpigraphProps): JSX.Element;
