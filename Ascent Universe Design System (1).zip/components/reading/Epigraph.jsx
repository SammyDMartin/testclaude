import React from 'react';

/**
 * Epigraph — the chapter epigraph block: an italic serif quote with an
 * em-dashed attribution, set off by an acid left rule. Pure Ascent voice.
 */
export function Epigraph({ children, cite, align = 'left', style = {}, ...rest }) {
  return (
    <figure style={{
      margin: 0,
      borderLeft: align === 'left' ? '2px solid var(--acid)' : 'none',
      paddingLeft: align === 'left' ? 'var(--space-4)' : 0,
      textAlign: align,
      maxWidth: '52ch',
      ...style,
    }} {...rest}>
      <blockquote style={{
        margin: 0,
        fontFamily: 'var(--font-serif)',
        fontStyle: 'italic',
        fontSize: 'var(--text-md)',
        lineHeight: 'var(--leading-snug)',
        color: 'var(--bone-soft)',
        textWrap: 'pretty',
      }}>{children}</blockquote>
      {cite ? (
        <figcaption style={{
          marginTop: 'var(--space-3)',
          fontFamily: 'var(--font-mono)',
          fontSize: 'var(--text-2xs)',
          letterSpacing: 'var(--track-wide)',
          textTransform: 'uppercase',
          color: 'var(--bone-faint)',
        }}>— {cite}</figcaption>
      ) : null}
    </figure>
  );
}
