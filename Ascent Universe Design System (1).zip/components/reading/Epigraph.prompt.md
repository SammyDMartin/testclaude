Chapter epigraph — italic serif quote + em-dashed attribution with an acid left rule. The universe leans on epigraphs (song lyrics, philosophy, in-universe texts).

```jsx
<Epigraph cite="The Reflections of Seeker">
  All the worlds that were will always have been.
</Epigraph>
<Epigraph align="center" cite="Striver creed">In toil, absolution. In strife, salvation.</Epigraph>
```

`align` `left` (rule) or `center` (no rule, for hero quotes). Keep quotes short — one or two lines.
