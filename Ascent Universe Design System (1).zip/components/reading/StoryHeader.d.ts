import { ReactNode, CSSProperties } from 'react';

/**
 * @startingPoint section="Reading" subtitle="Story / scene masthead" viewport="700x200"
 */
export interface StoryHeaderProps {
  /** Mono classification line, e.g. "2479 CE · HUMAN". */
  kicker?: ReactNode;
  title: ReactNode;
  /** Location / context subtitle. */
  subtitle?: ReactNode;
  /** Tints the kicker rule with a faction colour. */
  faction?: 'arco' | 'union' | 'dyn' | 'striver' | 'apathy' | 'utilitaria' | 'listener' | 'seeker';
  style?: CSSProperties;
}

/**
 * Masthead for a story / scene reader: mono era line, display title and an
 * optional location subtitle.
 * @startingPoint section="Reading" subtitle="Story / scene masthead" viewport="700x200"
 */
export function StoryHeader(props: StoryHeaderProps): JSX.Element;
