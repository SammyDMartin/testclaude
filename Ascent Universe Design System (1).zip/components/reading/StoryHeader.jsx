import React from 'react';

/**
 * StoryHeader — the masthead of a story / scene reader: a mono classification
 * line (era · attribution), the title, and an optional location subtitle.
 */
export function StoryHeader({ kicker, title, subtitle, faction, style = {}, ...rest }) {
  const factionColor = {
    arco: 'var(--arco)', union: 'var(--union)', dyn: 'var(--dyn)', striver: 'var(--striver)',
    apathy: 'var(--apathy)', utilitaria: 'var(--utilitaria)', listener: 'var(--listener)', seeker: 'var(--seeker)',
  }[faction] || 'var(--acid)';

  return (
    <header style={{ ...style }} {...rest}>
      {kicker ? (
        <div style={{
          display: 'flex', alignItems: 'center', gap: '10px',
          fontFamily: 'var(--font-mono)', fontSize: 'var(--text-2xs)',
          letterSpacing: 'var(--track-wider)', textTransform: 'uppercase',
          color: 'var(--bone-faint)', marginBottom: 'var(--space-3)',
        }}>
          <span aria-hidden="true" style={{ width: '24px', height: '1px', background: factionColor }} />
          {kicker}
        </div>
      ) : null}
      <h1 style={{
        fontFamily: 'var(--font-display)', fontWeight: 'var(--weight-semibold)',
        fontSize: 'var(--text-2xl)', letterSpacing: 'var(--track-tight)',
        lineHeight: 'var(--leading-tight)', color: 'var(--bone)', margin: 0,
      }}>{title}</h1>
      {subtitle ? (
        <div style={{
          fontFamily: 'var(--font-sans)', fontSize: 'var(--text-sm)',
          color: 'var(--bone-dim)', marginTop: 'var(--space-2)', letterSpacing: 'var(--track-wide)',
        }}>{subtitle}</div>
      ) : null}
    </header>
  );
}
