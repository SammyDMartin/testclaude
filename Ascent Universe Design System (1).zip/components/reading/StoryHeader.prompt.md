Masthead for a story or scene reader — mono era/attribution line, display title, optional location subtitle.

```jsx
<StoryHeader kicker="2479 CE · HUMAN" title="Ascent" subtitle="Conurbation One — the Hollow Tower" faction="dyn" />
<StoryHeader kicker="~3200 CE · AI-ASSISTED" title="The War of All Wars" />
```

`faction` tints the kicker rule. Pair below it with `.ax-reading` prose and an `Epigraph` for full effect.
