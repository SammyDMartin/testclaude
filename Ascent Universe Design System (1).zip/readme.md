# Ascent Universe — Design System

A brand & UI system for the **Ascent Universe**: a hard-science-fiction setting spanning ~100,000 BCE → ~3200 CE, told across two novels and sixteen short stories. It traces humanity's collision with the alien **Dyn** and the far-future war against the **Apathy** — a force that may be killing us for our own good.

This system exists to build a *superior* companion archive for the universe: story readers, intelligence dossiers, tactical reconstructions and marketing. It replaces the old generic neon-cyan "HUD" look with an identity drawn straight from the cover art.

---

## Sources (for the reader — you may not have access)

- **GitHub** — primary source of truth: `https://github.com/SammyDMartin/testclaude` (branch `master`). The companion site, all source texts (`source_texts/`), synopses and the comprehensive `UNIVERSE_REFERENCE.md`, plus the old `style.css` we are improving on. **Explore this repo to build more accurately** — it contains every story, character dossier and the canonical timeline.
- **Live fiction** — `https://ascentuniverse.wordpress.com` (the original published stories).
- **Uploaded artwork** (now in `assets/art/`): the *ascent* cover (`ascent_by_samsquared`), *A Dyn and Her Conscience* (pen & ink), and a character portrait triptych (`cropped-aurelie-vash3`). These are canonical and **must be used** in any Ascent design.

### How this improves the old site
The original site (`style.css` in the repo) leaned on a neon-cyan-on-black "sci-fi terminal" — a trope unconnected to the actual artwork. This system instead derives everything from the **cover**: a black **Dragon's Tooth** with red/cyan chromatic-aberration fringing on a painterly **acid-olive** field. The result is sharper, more literary and genuinely ownable. The Dragon's Tooth becomes the universe mark; chromatic aberration becomes the signature title treatment; **acid green** replaces neon cyan as the one color that means *Ascent*; bone/parchment text and a literary serif honor the prose.

---

## Content Fundamentals — how Ascent is written

**Voice.** Hard-SF and literary at once: lean, propulsive prose with real physics underneath, and a cold moral seriousness. The framing voice of the *archive* is an **intelligence dossier** — clipped, classified, declarative. The framing voice of the *fiction* is novelistic and interior.

- **Register & person.** In-universe materials are third-person and impersonal ("Classified dossiers on factions, personnel, vessels and threats"). Prose moves close-third into a POV character (Jan, Vash, Eszel, Hansun). Rarely "you" — except deliberately, as a weapon, in the Anthropic Trap ("You are almost certainly a simulation").
- **Casing.** Section organisers are **UPPERCASE, wide-tracked** (`READ`, `EXPLORE`, `EXPERIENCE`, `SIMULATE`). The wordmark is **lowercase** (`ascent`). Titles use Title Case. Dates are always epoch-stamped: `2479 CE`, `~100,000 BCE`.
- **Epigraphs.** Chapters and pages open with epigraphs — song lyrics, philosophy, in-universe texts. Use them. Canonical lines:
  - *"All the worlds that were will always have been."* — The Reflections of Seeker
  - *"In toil, absolution. In strife, salvation. In death, release."* — Striver creed
  - *"I am everything, it said. And for once, that was not a lie."* — The Listener
  - *"Anthropic traps are to be ignored."* — fleet engagement protocol
- **Diction.** Coined-but-plausible nouns carry the world: *warseeds, interstice, frameshift, Diamond Duster, Ascensor, conurbation, the false life, the Line, Emissary, Other Moon*. Capitalise factions and named technologies. Em-dashes for the literary turn; `·` and `//` as mono separators in UI.
- **Tone.** Melancholy, morally ambiguous, awe at deep time. No quips, no camp. **No emoji, ever.** Restraint is the brand — "an advanced civilisation's archive: clear, readable, nothing to prove."

---

## Visual Foundations

**Palette.** A green-black ink base (`--ink-900` `#080b08`), warm **bone** text (`--bone` `#e8e4d8`), and the signature **acid green** (`--acid` `#c8e021`, sampled from the cover) as the single accent. The **chromatic pair** — `--chroma-red` `#ff2d3a` and `--chroma-cyan` `#1fe3ff` — is reserved for the glitch wordmark and alerts. Each polity owns one hue (`--arco` amber, `--union` steel blue, `--dyn` purple, `--striver` blood red, `--apathy` cold near-white, `--utilitaria` = acid, `--listener` white, `--seeker` teal). See `tokens/colors.css`.

**Type.** Four voices, one job each (`tokens/typography.css`):
- **Chakra Petch** (display) — wordmark, hero, section titles. Engineered, squared, lowercase wordmark at `--track-widest`.
- **Saira** (sans) — UI body, cards, nav, descriptions.
- **Spectral** (serif) — long-form story / prose reading at `--measure-reading` (68ch), leading 1.82.
- **IBM Plex Mono** (mono) — data rows, telemetry, classification stamps, dates.
> ⚠ **Font substitution:** these are Google-Fonts approximations chosen to match the cover wordmark and the dual technical/literary voice — they are loaded over the web from `tokens/fonts.css`. The original art uses a specific (unknown) wordmark face. If you have the real font files, send them and they'll be embedded as local `@font-face` binaries.

**Backgrounds & texture.** The painterly cover field is rebuilt as `.ax-grunge` (layered acid/olive radial gradients on ink). Layer `.ax-grain` (SVG turbulence, ~4%) and `.ax-scanlines` (faint horizontal veil) over full-bleed surfaces. Hero gets a subtle acid **starfield** canvas. Imagery is run slightly **desaturated + higher contrast** (grayscale ~0.1, contrast ~1.05) so it sits in the green-black world; the ink illustration stays near-monochrome.

**Borders, radii, elevation.** This is engineered hardware: radii stay **sharp** (`--radius-sm` 2px, `--radius-md` 3px — the tooth is the only curve). Dividing is done with **hairlines** (`--border` bone @14%), each section marked by an **acid tick** (`.ax-rule` / `SectionLabel`). On the dark base, depth reads as **glow, not drop shadow** — `--glow-acid`, `--glow-acid-strong`; cards get `--shadow-panel` + a hairline.

**Cards.** Flat `--surface` (`#10140f`) with a 1px `--border`, 3px radius, a left accent rail in the relevant faction hue. Hover: lift 2px, edge goes acid, the title gains a chromatic offset, the arrow nudges right. No coloured-left-border-only "callout" cards; no gradients-for-gradient's-sake.

**Motion.** Quiet and mechanical. Transitions ~0.15–0.28s on `--ease-out`; the chromatic offset widens on hover; stat bars sweep on `--dur-slow`. No bounce, no infinite decorative loops. Honors `prefers-reduced-motion`.

**Hover / press.** Hover = acid color + acid edge + glow (never a lighter grey fill). Press = translateY(1px) + the deep acid (`--acid-deep`). Focus = 2px acid outline, 2px offset.

---

## Iconography

The universe uses **no icon font and no illustrative SVG icon set** — and deliberately so. Iconography is:
- **Geometric unicode glyphs**, set in mono, used sparingly as nav/section marks: `▣ ◫ ⟡ ◈ ◉ ✦ ■ ▷ ◌ ⚔ →`. They read as archival/typographic, not decorative.
- The **CSS diamond** (`clip-path: polygon(50% 0, 100% 50, 50% 100, 0 50)`) — used in `FactionTag` and the nav brand as the recurring small mark.
- The **Dragon's Tooth** mark (`assets/brand/`) — the one true logo, in bone / acid / ink. Derived programmatically from the cover (thresholded silhouette), not hand-drawn.

**No emoji.** No multicolor icons. If a future surface genuinely needs lined icons (e.g. a settings UI), substitute a **thin geometric** CDN set (e.g. Lucide at ~1.5px stroke) and flag it — but prefer unicode glyphs and the diamond first.

---

## Index / Manifest

**Foundations**
- `styles.css` — the single entry point consumers link (import manifest only).
- `tokens/` — `fonts.css`, `colors.css`, `typography.css`, `spacing.css`, `effects.css`, `base.css`.
- `guidelines/cards/` — 19 foundation specimen cards (Colors, Type, Spacing, Brand) shown in the Design System tab.

**Assets**
- `assets/art/` — `ascent-cover.webp`, `dyn-and-conscience.webp`, `portraits-triptych.jpg` (canonical artwork).
- `assets/brand/` — `dragons-tooth.png` (bone), `dragons-tooth-acid.png`, `dragons-tooth-ink.png` (the mark).

**Components** (`components/`) — `const { X } = window.AscentUniverseDesignSystem_d01098`
- `core/` — **Button**, **Badge**, **FactionTag**, **GlitchTitle**
- `data/` — **Panel**, **DataRow**, **StatBar**
- `navigation/` — **NavCard**, **SectionLabel**
- `reading/` — **Epigraph**, **StoryHeader**

**UI kit** (`ui_kits/companion_archive/`) — the redesigned website: interactive `index.html` clicking through **Home** (the superior frontpage), **Codex** (intelligence dossiers), **Reader** (story reader), and **Worlds**.

**Other**
- `SKILL.md` — makes this folder usable as a downloadable Agent Skill.
- `readme.md` — this file.

> The compiler generates `_ds_bundle.js`, `_ds_manifest.json` and `_adherence.oxlintrc.json` — never edit those by hand.
