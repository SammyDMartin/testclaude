/* Codex.jsx — interactive intelligence dossiers. */
const { useState: useCodexState } = React;

function CodexScreen() {
  const { Panel, DataRow, StatBar, Badge, FactionTag, SectionLabel } = window.AscentUniverseDesignSystem_d01098;
  const entries = window.ARCHIVE.codex;
  const [activeId, setActiveId] = useCodexState(entries[0].id);
  const active = entries.find((e) => e.id === activeId) || entries[0];

  const threatTone = (t) => (t === 'EXISTENTIAL' || t === 'CRITICAL') ? 'alert'
    : (t === 'DORMANT' || t === 'COOPERATIVE') ? 'acid' : 'dim';

  return (
    <div style={{ maxWidth: 'var(--width-content)', margin: '0 auto', padding: 'var(--space-8) var(--space-6) var(--space-12)' }}>
      <div style={{ marginBottom: 'var(--space-3)', fontFamily: 'var(--font-mono)', fontSize: 'var(--text-2xs)', letterSpacing: 'var(--track-widest)', textTransform: 'uppercase', color: 'var(--chroma-red)' }}>
        ◈ Classified — Arco Intelligence Codex
      </div>
      <h1 style={{ fontFamily: 'var(--font-display)', fontWeight: 600, fontSize: 'var(--text-2xl)', letterSpacing: 'var(--track-tight)', color: 'var(--bone)', marginBottom: 'var(--space-8)' }}>
        Intelligence Codex
      </h1>

      <div style={{ display: 'grid', gridTemplateColumns: '280px 1fr', gap: 'var(--space-6)', alignItems: 'start' }}>
        {/* index */}
        <aside>
          <SectionLabel style={{ marginBottom: 'var(--space-4)' }}>Dossiers</SectionLabel>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '2px' }}>
            {entries.map((e) => {
              const on = e.id === activeId;
              return (
                <button key={e.id} onClick={() => setActiveId(e.id)} style={{
                  textAlign: 'left', padding: 'var(--space-3)', borderRadius: 'var(--radius-sm)',
                  border: '1px solid', borderColor: on ? 'var(--border-acid)' : 'transparent',
                  background: on ? 'var(--acid-ghost)' : 'transparent',
                  transition: 'all var(--dur-fast) var(--ease-out)', cursor: 'pointer',
                }}
                  onMouseEnter={(ev) => { if (!on) ev.currentTarget.style.background = 'var(--surface)'; }}
                  onMouseLeave={(ev) => { if (!on) ev.currentTarget.style.background = 'transparent'; }}>
                  <div style={{ marginBottom: '6px' }}><FactionTag faction={e.faction} size="sm">{e.kind}</FactionTag></div>
                  <div style={{ fontFamily: 'var(--font-display)', fontWeight: 600, fontSize: 'var(--text-sm)', color: on ? 'var(--acid)' : 'var(--bone)', letterSpacing: 'var(--track-wide)' }}>{e.name}</div>
                </button>
              );
            })}
          </div>
        </aside>

        {/* detail */}
        <Panel
          title={active.name}
          accent={`var(--${active.faction})`}
          badge={<Badge status={threatTone(active.threat) === 'alert' ? 'alert' : 'nominal'}>{active.threat}</Badge>}
        >
          <div style={{ display: 'flex', alignItems: 'center', gap: 'var(--space-4)', marginBottom: 'var(--space-4)', flexWrap: 'wrap' }}>
            <FactionTag faction={active.faction} />
            <span style={{ fontFamily: 'var(--font-mono)', fontSize: 'var(--text-2xs)', letterSpacing: 'var(--track-wide)', color: 'var(--bone-faint)' }}>{active.kind} · {active.era}</span>
          </div>

          <p style={{ fontFamily: 'var(--font-serif)', fontSize: 'var(--text-base)', lineHeight: 'var(--leading-reading)', color: 'var(--bone-soft)', marginBottom: 'var(--space-5)', maxWidth: '64ch' }}>
            {active.summary}
          </p>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 'var(--space-6)' }}>
            <div>
              <div style={{ fontFamily: 'var(--font-mono)', fontSize: 'var(--text-2xs)', letterSpacing: 'var(--track-wider)', textTransform: 'uppercase', color: 'var(--bone-faint)', marginBottom: 'var(--space-2)' }}>Specification</div>
              {active.rows.map((r, i) => (
                <DataRow key={r.label} label={r.label} value={r.value} tone={r.tone} last={i === active.rows.length - 1} />
              ))}
            </div>
            <div>
              <div style={{ fontFamily: 'var(--font-mono)', fontSize: 'var(--text-2xs)', letterSpacing: 'var(--track-wider)', textTransform: 'uppercase', color: 'var(--bone-faint)', marginBottom: 'var(--space-3)' }}>Assessment</div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-4)' }}>
                {active.stats.map((s) => (
                  <StatBar key={s.label} label={s.label} value={s.value} color={s.color || 'var(--acid)'} />
                ))}
              </div>
            </div>
          </div>
        </Panel>
      </div>
    </div>
  );
}

window.CodexScreen = CodexScreen;
