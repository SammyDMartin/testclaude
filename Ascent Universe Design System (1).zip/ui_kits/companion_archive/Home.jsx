/* Home.jsx — the Ascent Universe frontpage. */
const { useEffect: useHomeEffect, useRef: useHomeRef } = React;

function Starfield() {
  const ref = useHomeRef(null);
  useHomeEffect(() => {
    const c = ref.current; if (!c) return;
    const ctx = c.getContext('2d');
    let raf, t = 0;
    const resize = () => { c.width = c.offsetWidth; c.height = c.offsetHeight; };
    resize();
    const stars = Array.from({ length: 150 }, () => ({
      x: Math.random(), y: Math.random(), s: Math.random() * 1.4 + 0.3,
      b: Math.random(), sp: Math.random() * 0.5 + 0.15,
    }));
    const draw = () => {
      raf = requestAnimationFrame(draw); t += 0.01;
      ctx.clearRect(0, 0, c.width, c.height);
      for (const st of stars) {
        ctx.fillStyle = `rgba(200,224,33,${0.10 + Math.sin(t * st.sp + st.b * 6.28) * 0.10})`;
        ctx.beginPath(); ctx.arc(st.x * c.width, st.y * c.height, st.s, 0, Math.PI * 2); ctx.fill();
      }
    };
    draw();
    window.addEventListener('resize', resize);
    return () => { cancelAnimationFrame(raf); window.removeEventListener('resize', resize); };
  }, []);
  return <canvas ref={ref} style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', zIndex: 0 }} />;
}

function HomeScreen({ onNavigate }) {
  const { GlitchTitle, NavCard, SectionLabel, Button, Epigraph, FactionTag } = window.AscentUniverseDesignSystem_d01098;
  const A = window.ARCHIVE;
  let fileNo = 0;

  return (
    <div>
      {/* ── HERO ─────────────────────────────────────────────────────── */}
      <header className="ax-grunge ax-grain" style={{ position: 'relative', overflow: 'hidden', borderBottom: '1px solid var(--border)' }}>
        <Starfield />
        <div className="ax-scanlines" />
        {/* faint tooth watermark */}
        <img src="../../assets/brand/dragons-tooth-acid.png" alt="" aria-hidden="true" style={{
          position: 'absolute', right: '-3%', top: '50%', transform: 'translateY(-50%)',
          height: '118%', width: 'auto', opacity: 0.06, zIndex: 1, pointerEvents: 'none',
        }} />
        <div style={{
          position: 'relative', zIndex: 4, maxWidth: 'var(--width-content)', margin: '0 auto',
          padding: 'var(--space-16) var(--space-6) var(--space-12)',
        }}>
          <div style={{
            fontFamily: 'var(--font-mono)', fontSize: 'var(--text-2xs)',
            letterSpacing: 'var(--track-widest)', textTransform: 'uppercase',
            color: 'var(--bone-dim)', marginBottom: 'var(--space-5)',
          }}>Ascent Universe <span style={{ color: 'var(--acid)' }}>//</span> Companion Archive</div>

          <GlitchTitle as="h1" size="hero" weight={300} style={{ marginBottom: 'var(--space-4)' }}>ascent</GlitchTitle>

          <div style={{ display: 'flex', alignItems: 'center', gap: 'var(--space-4)', marginBottom: 'var(--space-5)' }}>
            <span style={{ width: '64px', height: '1px', background: 'var(--acid)' }} />
            <span style={{
              fontFamily: 'var(--font-mono)', fontSize: 'var(--text-sm)',
              letterSpacing: 'var(--track-wider)', color: 'var(--bone-soft)',
            }}>~100,000 BCE — ~3200 CE</span>
          </div>

          <p style={{
            fontFamily: 'var(--font-sans)', fontSize: 'var(--text-md)', fontWeight: 400,
            lineHeight: 'var(--leading-normal)', color: 'var(--bone-soft)', maxWidth: '60ch',
            marginBottom: 'var(--space-3)',
          }}>
            A science fiction universe spanning a hundred thousand years. Two novels and sixteen short
            stories trace the collision between humanity and the alien <strong style={{ color: 'var(--dyn)', fontWeight: 500 }}>Dyn</strong> —
            from deep prehistory to the far-future war against the <strong style={{ color: 'var(--apathy)', fontWeight: 500 }}>Apathy</strong>,
            a force that may be killing us for our own good.
          </p>
          <p style={{
            fontFamily: 'var(--font-sans)', fontSize: 'var(--text-sm)',
            lineHeight: 'var(--leading-normal)', color: 'var(--bone-dim)', maxWidth: '58ch',
            marginBottom: 'var(--space-6)',
          }}>
            Story readers, tactical reconstructions, intelligence dossiers and 3D models, built around
            the source fiction.
          </p>

          <div style={{ display: 'flex', gap: 'var(--space-3)', flexWrap: 'wrap' }}>
            <Button variant="primary" size="lg" icon="▣" onClick={() => onNavigate('reader')}>Enter the Archive</Button>
            <Button variant="secondary" size="lg" icon="◈" onClick={() => onNavigate('codex')}>Intelligence Codex</Button>
          </div>
        </div>
      </header>

      {/* ── FEATURED — the Dyn ───────────────────────────────────────── */}
      <section style={{
        display: 'grid', gridTemplateColumns: '1.1fr 1fr', alignItems: 'stretch',
        maxWidth: 'var(--width-wide)', margin: '0 auto',
        borderBottom: '1px solid var(--border)',
      }}>
        <div style={{ position: 'relative', minHeight: '380px', borderRight: '1px solid var(--border)', overflow: 'hidden', background: 'var(--ink-950)' }}>
          <img src="../../assets/art/dyn-and-conscience.webp" alt="A Dyn and Her Conscience" style={{
            position: 'absolute', inset: 0, width: '100%', height: '100%', objectFit: 'cover',
            objectPosition: 'center', filter: 'grayscale(0.1) contrast(1.05) brightness(0.92)',
          }} />
          <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(90deg, transparent 55%, rgba(8,11,8,0.85) 100%)' }} />
          <span style={{
            position: 'absolute', left: 'var(--space-5)', bottom: 'var(--space-4)', zIndex: 2,
            fontFamily: 'var(--font-mono)', fontSize: 'var(--text-2xs)', letterSpacing: 'var(--track-wide)',
            color: 'var(--ink-950)', background: 'var(--bone)', padding: '3px 8px', borderRadius: 'var(--radius-sm)',
          }}>PLATE 01 · A DYN AND HER CONSCIENCE</span>
        </div>
        <div className="ax-grunge" style={{ padding: 'var(--space-10) var(--space-8)', display: 'flex', flexDirection: 'column', justifyContent: 'center', gap: 'var(--space-5)' }}>
          <FactionTag faction="dyn">The Dyn</FactionTag>
          <Epigraph cite="Starwhisp — K'txl's assessment">
            Virulent ideas rule your minds. That is why you are insane — and why you cannot be allowed to continue.
          </Epigraph>
          <p style={{ fontFamily: 'var(--font-serif)', fontSize: 'var(--text-base)', lineHeight: 'var(--leading-reading)', color: 'var(--bone-dim)', maxWidth: '46ch' }}>
            Y-shaped, jaw-plated, bound by pheromone into a single Line across ten thousand generations.
            No concept of morality, trade or compromise — only dominance, submission, and the survival of
            the whole. They invaded not from malice, but from a cold and rational fear of what our conscience
            would compel us to do.
          </p>
          <div><Button variant="ghost" icon="→" onClick={() => onNavigate('codex')}>Open the Dyn dossier</Button></div>
        </div>
      </section>

      {/* ── NAV SECTIONS ─────────────────────────────────────────────── */}
      <main style={{ maxWidth: 'var(--width-content)', margin: '0 auto', padding: 'var(--space-10) var(--space-6) var(--space-12)' }}>
        {A.navSections.map((sec) => (
          <div key={sec.label} style={{ marginBottom: 'var(--space-10)' }}>
            <SectionLabel style={{ marginBottom: 'var(--space-5)' }}>{sec.label}</SectionLabel>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 'var(--space-4)' }}>
              {sec.cards.map((card) => (
                <NavCard key={card.title} kicker={card.kicker} title={card.title} glyph={card.glyph}
                  accent={card.accent} wide={card.wide} index={fileNo += 1}
                  href="#" onClick={(e) => { e.preventDefault(); onNavigate(card.target); }}>
                  {card.desc}
                </NavCard>
              ))}
            </div>
          </div>
        ))}
      </main>

      {/* ── DRAMATIS PERSONAE ────────────────────────────────────────── */}
      <section style={{ borderTop: '1px solid var(--border)', background: 'var(--ink-950)' }}>
        <div style={{ maxWidth: 'var(--width-content)', margin: '0 auto', padding: 'var(--space-10) var(--space-6)' }}>
          <SectionLabel style={{ marginBottom: 'var(--space-5)' }}>Dramatis Personae</SectionLabel>
          <figure style={{ margin: 0, position: 'relative', border: '1px solid var(--border)', borderRadius: 'var(--radius-md)', overflow: 'hidden' }}>
            <img src="../../assets/art/portraits-triptych.jpg" alt="Aurelie, Vash and the Emissary" style={{
              width: '100%', height: 'auto', display: 'block', filter: 'grayscale(0.12) contrast(1.03)',
            }} />
            <figcaption style={{
              display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)',
              borderTop: '1px solid var(--border)', background: 'var(--surface)',
            }}>
              {[
                { c: 'var(--acid)', n: 'Aurelie', d: 'Christo\u2019s lieutenant — and the hand on the warseeds' },
                { c: 'var(--bone)', n: 'Vash', d: 'Arco\u2019s Ambassador — the lesser evil, made flesh' },
                { c: 'var(--listener)', n: 'The Emissary', d: 'A sub-unit of the dead Utilitaria — the last echo of a god-mind' },
              ].map((p, i) => (
                <div key={p.n} style={{ padding: 'var(--space-4)', borderRight: i < 2 ? '1px solid var(--border)' : 'none' }}>
                  <div style={{ fontFamily: 'var(--font-display)', fontWeight: 600, fontSize: 'var(--text-base)', color: p.c, letterSpacing: 'var(--track-wide)' }}>{p.n}</div>
                  <div style={{ fontFamily: 'var(--font-sans)', fontSize: 'var(--text-sm)', color: 'var(--bone-dim)', marginTop: '4px' }}>{p.d}</div>
                </div>
              ))}
            </figcaption>
          </figure>
        </div>
      </section>

      {/* ── CLOSING ──────────────────────────────────────────────────── */}
      <section className="ax-grunge" style={{ borderTop: '1px solid var(--border)', textAlign: 'center', padding: 'var(--space-12) var(--space-6)' }}>
        <Epigraph align="center" cite="The Listener" style={{ margin: '0 auto var(--space-6)' }}>
          I am everything, it said. And for once, that was not a lie.
        </Epigraph>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '12px' }}>
          <img src="../../assets/brand/dragons-tooth.png" alt="" style={{ height: '28px', opacity: 0.8 }} />
          <span style={{
            fontFamily: 'var(--font-display)', fontWeight: 300, fontSize: 'var(--text-lg)',
            letterSpacing: 'var(--track-widest)', color: 'var(--bone-dim)', textTransform: 'lowercase',
          }}>ascent</span>
        </div>
      </section>
    </div>
  );
}

window.HomeScreen = HomeScreen;
