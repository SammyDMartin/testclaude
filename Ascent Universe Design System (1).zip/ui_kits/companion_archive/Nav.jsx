/* Nav.jsx — shared top navigation + status bar for the Companion Archive. */
const { useState: useNavState } = React;

function NavLink({ label, active, onSelect }) {
  const [hover, setHover] = useNavState(false);
  const style = {
    fontFamily: 'var(--font-mono)', fontSize: 'var(--text-2xs)',
    letterSpacing: 'var(--track-wider)', textTransform: 'uppercase',
    padding: '6px 11px', borderRadius: 'var(--radius-sm)',
    border: '1px solid transparent',
    background: 'transparent',
    color: (active || hover) ? 'var(--acid)' : 'var(--bone-dim)',
    textDecoration: 'none',
  };
  if (active) {
    style.borderColor = 'var(--border-acid)';
    style.background = 'var(--acid-ghost)';
  }
  return (
    <a href="#" onClick={(e) => { e.preventDefault(); onSelect(); }}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      style={style}>{label}</a>
  );
}

function Nav({ current, onNavigate }) {
  const links = [
    { id: 'home', label: 'Home' },
    { id: 'reader', label: 'Stories' },
    { id: 'codex', label: 'Codex' },
    { id: 'worlds', label: 'Worlds' },
  ];
  return (
    <nav style={{
      position: 'sticky', top: 0, zIndex: 100,
      height: 'var(--nav-height)',
      display: 'flex', alignItems: 'center', gap: 'var(--space-4)',
      padding: '0 var(--space-5)',
      background: 'rgba(8, 11, 8, 0.82)',
      borderBottom: '1px solid var(--border)',
      backdropFilter: 'blur(14px)',
    }}>
      <a href="#" onClick={(e) => { e.preventDefault(); onNavigate('home'); }}
        style={{ display: 'flex', alignItems: 'center', gap: '10px', textDecoration: 'none', flex: 'none' }}>
        <img src="../../assets/brand/dragons-tooth.png" alt="" style={{ height: '22px', width: 'auto' }} />
        <span style={{
          fontFamily: 'var(--font-display)', fontWeight: 300, fontSize: 'var(--text-base)',
          letterSpacing: 'var(--track-widest)', color: 'var(--bone)', textTransform: 'lowercase',
          textShadow: 'var(--chroma-text-soft)',
        }}>ascent</span>
      </a>
      <span style={{ width: '1px', height: '18px', background: 'var(--border)', flex: 'none' }} />
      <div style={{ display: 'flex', gap: '2px', flex: 1 }}>
        {links.map((l) => (
          <NavLink key={l.id + (current === l.id ? '-on' : '-off')} label={l.label} active={current === l.id} onSelect={() => onNavigate(l.id)} />
        ))}
      </div>
      <span style={{
        fontFamily: 'var(--font-mono)', fontSize: 'var(--text-2xs)',
        letterSpacing: 'var(--track-wide)', color: 'var(--bone-faint)', flex: 'none',
      }}>COMPANION ARCHIVE</span>
    </nav>
  );
}

function StatusBar({ note }) {
  return (
    <footer style={{
      position: 'sticky', bottom: 0, zIndex: 90,
      height: 'var(--status-height)',
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      padding: '0 var(--space-5)',
      background: 'rgba(8, 11, 8, 0.9)', borderTop: '1px solid var(--border)',
      fontFamily: 'var(--font-mono)', fontSize: 'var(--text-2xs)',
      letterSpacing: 'var(--track-wide)', color: 'var(--bone-faint)',
    }}>
      <span><span style={{ color: 'var(--acid)' }}>●</span> ARCHIVE ONLINE</span>
      <span>{note || '~100,000 BCE — ~3200 CE'}</span>
      <span>ARCO GEN-STREAM</span>
    </footer>
  );
}

window.Nav = Nav;
window.StatusBar = StatusBar;
