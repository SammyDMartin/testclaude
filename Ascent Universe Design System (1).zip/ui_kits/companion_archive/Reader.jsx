/* Reader.jsx — literary story reader. */
const { useState: useReaderState } = React;

function ReaderScreen() {
  const { StoryHeader, Epigraph, FactionTag, Button } = window.AscentUniverseDesignSystem_d01098;
  const stories = window.ARCHIVE.stories;
  const [idx, setIdx] = useReaderState(0);
  const s = stories[idx];

  return (
    <div style={{ display: 'grid', gridTemplateColumns: '240px 1fr', minHeight: 'calc(100vh - var(--nav-height) - var(--status-height))' }}>
      {/* contents rail */}
      <aside style={{ borderRight: '1px solid var(--border)', padding: 'var(--space-6) var(--space-4)', position: 'sticky', top: 'var(--nav-height)', alignSelf: 'start' }}>
        <div style={{ fontFamily: 'var(--font-mono)', fontSize: 'var(--text-2xs)', letterSpacing: 'var(--track-widest)', textTransform: 'uppercase', color: 'var(--bone-dim)', marginBottom: 'var(--space-4)' }}>Contents</div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
          {stories.map((st, i) => {
            const on = i === idx;
            return (
              <button key={st.id} onClick={() => setIdx(i)} style={{
                textAlign: 'left', padding: '8px 10px', borderRadius: 'var(--radius-sm)',
                borderLeft: '2px solid', borderLeftColor: on ? 'var(--acid)' : 'var(--border)',
                background: on ? 'var(--acid-ghost)' : 'transparent', cursor: 'pointer',
                transition: 'all var(--dur-fast) var(--ease-out)',
              }}>
                <div style={{ fontFamily: 'var(--font-display)', fontWeight: 500, fontSize: 'var(--text-sm)', color: on ? 'var(--acid)' : 'var(--bone)', letterSpacing: 'var(--track-wide)' }}>{st.title}</div>
                <div style={{ fontFamily: 'var(--font-mono)', fontSize: 'var(--text-2xs)', color: 'var(--bone-faint)', marginTop: '2px' }}>{st.era}</div>
              </button>
            );
          })}
        </div>
      </aside>

      {/* reading column */}
      <main className="ax-grunge" style={{ padding: 'var(--space-10) var(--space-8)' }}>
        <div style={{ maxWidth: '72ch', margin: '0 auto' }}>
          <div style={{ marginBottom: 'var(--space-4)' }}>
            <FactionTag faction={s.faction} size="sm">{s.attribution}</FactionTag>
          </div>
          <StoryHeader kicker={`${s.era} · ${s.attribution}`} title={s.title} subtitle={s.subtitle} faction={s.faction} style={{ marginBottom: 'var(--space-6)' }} />
          <Epigraph cite={s.cite} style={{ marginBottom: 'var(--space-8)' }}>{s.epigraph}</Epigraph>

          <div className="ax-reading" style={{ maxWidth: 'none' }}>
            {s.body.map((para, i) => (
              <p key={i} style={i === 0 ? { marginTop: 0 } : null}>
                {i === 0 ? (
                  <span style={{ float: 'left', fontFamily: 'var(--font-display)', fontWeight: 600, fontSize: '3.4rem', lineHeight: 0.78, color: 'var(--acid)', margin: '4px 12px 0 0' }}>{para.charAt(0)}</span>
                ) : null}
                {i === 0 ? para.slice(1) : para}
              </p>
            ))}
          </div>

          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 'var(--space-8)', paddingTop: 'var(--space-5)', borderTop: '1px solid var(--border)' }}>
            <Button variant="ghost" disabled={idx === 0} onClick={() => setIdx(Math.max(0, idx - 1))}>← Previous</Button>
            <span style={{ fontFamily: 'var(--font-mono)', fontSize: 'var(--text-2xs)', letterSpacing: 'var(--track-wide)', color: 'var(--bone-faint)' }}>{String(idx + 1).padStart(2, '0')} / {String(stories.length).padStart(2, '0')}</span>
            <Button variant="secondary" disabled={idx === stories.length - 1} icon="→" onClick={() => setIdx(Math.min(stories.length - 1, idx + 1))}>Next</Button>
          </div>
        </div>
      </main>
    </div>
  );
}

window.ReaderScreen = ReaderScreen;
