/* Worlds.jsx — atmospheric profiles of the major settings. */
function WorldsScreen() {
  const { Panel, DataRow, Badge, GlitchTitle } = window.AscentUniverseDesignSystem_d01098;

  const worlds = [
    { name: 'Firsthome', faction: 'seeker', era: '~100,000 BCE', tag: 'Dyn homeworld',
      desc: 'A world tidally locked to a red dwarf. A habitable Dusk band separates the scorched Day from the frozen Night. Where Seeker first saw the stars.',
      rows: [['Star', 'Red dwarf'], ['Habitable', 'The Dusk band'], ['Native', 'The Dyn']] },
    { name: 'Occupied Earth', faction: 'dyn', era: '2314–2479 CE', tag: 'A global prison',
      desc: 'Conurbation arcologies of twenty-two billion; single-person farms; the false-life wasteland creeping between cities. The Ascensor threads surface to firmament.',
      rows: [['Government', 'Arco (puppet)'], ['Hazard', 'The false life'], ['Link', 'The Ascensor']] },
    { name: 'Kailash', faction: 'listener', era: '2937 CE', tag: 'The dying world',
      desc: 'An ancient Mars-like world on the fringe of a sterile galaxy. Rust plains, karst pits, ballistic arcs of matter. Twelve Other Moons hide in its Oort cloud.',
      rows: [['Star', 'Red giant'], ['Sky', 'Blue-black'], ['Cache', '12 Other Moons']] },
    { name: 'The Interstice', faction: 'union', era: '2909 CE', tag: 'The chokepoint',
      desc: 'A wormhole at the trailing Lagrange of the gas giant Deliverance — the strategic gate between Arco and Union space. Site of the Atbarah attack and the Battle of Threshold.',
      rows: [['Type', 'Ancient wormhole'], ['Builders', 'The Others'], ['Battle', 'Threshold, 2909']] },
  ];

  return (
    <div style={{ maxWidth: 'var(--width-content)', margin: '0 auto', padding: 'var(--space-8) var(--space-6) var(--space-12)' }}>
      <div style={{ marginBottom: 'var(--space-3)', fontFamily: 'var(--font-mono)', fontSize: 'var(--text-2xs)', letterSpacing: 'var(--track-widest)', textTransform: 'uppercase', color: 'var(--arco)' }}>◉ Worlds & Eras</div>
      <GlitchTitle as="h1" size="lg" lowercase={false} style={{ marginBottom: 'var(--space-8)' }}>Worlds &amp; Eras</GlitchTitle>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 'var(--space-4)' }}>
        {worlds.map((w) => (
          <Panel key={w.name} title={w.name} accent={`var(--${w.faction})`}
            badge={<Badge status="standby">{w.era}</Badge>}>
            <div style={{ fontFamily: 'var(--font-mono)', fontSize: 'var(--text-2xs)', letterSpacing: 'var(--track-wide)', textTransform: 'uppercase', color: `var(--${w.faction})`, marginBottom: 'var(--space-3)' }}>{w.tag}</div>
            <p style={{ fontFamily: 'var(--font-serif)', fontSize: 'var(--text-base)', lineHeight: 'var(--leading-reading)', color: 'var(--bone-soft)', marginBottom: 'var(--space-4)' }}>{w.desc}</p>
            {w.rows.map((r, i) => <DataRow key={r[0]} label={r[0]} value={r[1]} last={i === w.rows.length - 1} />)}
          </Panel>
        ))}
      </div>
    </div>
  );
}

window.WorldsScreen = WorldsScreen;
