/* Ascent Universe — archive content (in-universe). Plain data, no framework. */
window.ARCHIVE = {

  navSections: [
    {
      label: 'Read',
      cards: [
        { kicker: 'READ · 18 STORIES', title: 'Stories', glyph: '▣', accent: 'var(--acid)', target: 'reader',
          desc: 'All fiction — eighteen works from ~100,000 BCE to ~3200 CE. Novels, short stories and interactive readers.' },
        { kicker: 'MANUSCRIPTS', title: 'Drafts', glyph: '◫', accent: 'var(--bone-dim)', target: 'reader',
          desc: 'Second-draft manuscripts for Ascent and Eszel & The Listener. Chapter-by-chapter browsing.' },
      ],
    },
    {
      label: 'Explore',
      cards: [
        { kicker: 'CHRONOLOGY', title: 'Historical Timeline', glyph: '⟡', accent: 'var(--seeker)', target: 'codex',
          desc: 'From the Dyn deep past through the Battle of the Interstice to the Apathy War.' },
        { kicker: 'INTELLIGENCE', title: 'Codex', glyph: '◈', accent: 'var(--chroma-red)', target: 'codex',
          desc: 'Classified dossiers on factions, personnel, vessels and threats. Arco, Union, the Dyn, the Strivers, the Apathy.' },
        { kicker: 'WORLDS & ERAS', title: 'Worlds', glyph: '◉', accent: 'var(--arco)', target: 'codex',
          desc: 'From Firsthome to the Apathy War. Atmospheric profiles of the major settings and epochs.' },
        { kicker: 'SCIENCE', title: 'Compendium', glyph: '✦', accent: 'var(--acid)', target: 'codex',
          desc: 'The real physics behind the fiction. ABC drives, Diamond Dusters, hyperdiamond armour, warseeds.' },
      ],
    },
    {
      label: 'Experience',
      cards: [
        { kicker: 'EXPERIENCE', title: 'The Anthropic Trap', glyph: '■', accent: 'var(--striver)', target: 'codex', wide: true,
          desc: 'You are almost certainly a simulation. The Apathy has run this scenario a million times. Do you surrender?' },
        { kicker: 'DIPLOMATIC CHANNEL', title: 'Talk to the Utilitaria', glyph: '▷', accent: 'var(--utilitaria)', target: 'codex',
          desc: 'Open a channel with an Emissary. The collective will speaks through a singular vessel.' },
        { kicker: 'IN-UNIVERSE TEXT', title: 'Reflections of Seeker', glyph: '◌', accent: 'var(--seeker)', target: 'reader',
          desc: '"All the worlds that were will always have been." The Dyn philosophical text.' },
      ],
    },
    {
      label: 'Simulate',
      cards: [
        { kicker: 'PLAYABLE RTS', title: 'Threshold: First Fleet', glyph: '⚔', accent: 'var(--union)', target: 'codex', wide: true,
          desc: 'Command Union\u2019s First Fleet at the Battle of Threshold, 2909 CE. Ten destroyer battlegroups against Arco warships at true scale. History records one kill. Beat it.' },
        { kicker: 'PLAYABLE RTS', title: 'War of All Wars', glyph: '⚔', accent: 'var(--apathy)', target: 'codex', wide: true,
          desc: 'The Apathy approaches — an Earth-mass alien god at 40,000 G. Command A-spheres and D-spheres across light-minutes. Buy time for evacuation, or destroy it.' },
      ],
    },
  ],

  codex: [
    {
      id: 'annihilator', faction: 'arco', name: 'Annihilator-Class IPAV',
      kind: 'VESSEL', threat: 'CRITICAL', era: '2479 CE',
      summary: 'Arco\u2019s heaviest interplanetary assault vehicle. Spinal-mount Diamond Duster, hyperdiamond Whipple armour, antimatter beamed-core drive. One ship devastated Union\u2019s First Fleet at Threshold.',
      rows: [
        { label: 'Class', value: 'IP Assault Vehicle' },
        { label: 'Drive', value: 'ABC · 0.12 c exhaust', tone: 'acid' },
        { label: 'Primary', value: '500mm Diamond Duster' },
        { label: 'Armour', value: 'Hyperdiamond Whipple' },
        { label: 'Threat', value: 'CRITICAL', tone: 'alert' },
      ],
      stats: [
        { label: 'Reactor output', value: 88 },
        { label: 'Armour rating', value: 94, color: 'var(--arco)' },
        { label: 'Duster charge', value: 71, color: 'var(--acid)' },
      ],
    },
    {
      id: 'ktxl', faction: 'dyn', name: 'K\u2019txl — "Liar to Animals"',
      kind: 'PERSONNEL', threat: 'COOPERATIVE', era: '2310–3200 CE',
      summary: 'Female Dyn administrator. Initiated first contact at Tau Ceti, became Earth\u2019s Dynic administrator during the occupation, and is still referenced in the Apathy War. One of the few Dyn who transcends the species\u2019 amorality — she sounds almost human, with an inflection that is somehow off.',
      rows: [
        { label: 'Species', value: 'Dyn' },
        { label: 'Role', value: 'Administrator / envoy' },
        { label: 'First contact', value: 'Tau Ceti, 2310 CE', tone: 'info' },
        { label: 'Status', value: 'Persistent across eras', tone: 'acid' },
      ],
      stats: [
        { label: 'Diplomatic standing', value: 76, color: 'var(--dyn)' },
        { label: 'Threat to humans', value: 22, color: 'var(--chroma-red)' },
      ],
    },
    {
      id: 'apathy', faction: 'apathy', name: 'The Apathy',
      kind: 'THREAT', threat: 'EXISTENTIAL', era: 'post-3000 CE',
      summary: 'Berserker machines of unknown origin — possibly spacetime defects. Earth-mass agglomerations decelerating at 40,000 G. They replicate by consuming mass, are practically indestructible, and deploy anti-mind affects and anthropic traps. Explaining their motives would pose "a risk to all that is conscious."',
      rows: [
        { label: 'Origin', value: 'Unknown' },
        { label: 'Mass', value: '~1 Earth mass' },
        { label: 'Deceleration', value: '40,000 G', tone: 'alert' },
        { label: 'Weapon', value: 'Anti-mind affect; anthropic trap', tone: 'alert' },
        { label: 'Threat', value: 'EXISTENTIAL', tone: 'alert' },
      ],
      stats: [
        { label: 'Indestructibility', value: 98, color: 'var(--apathy)' },
        { label: 'Comprehensibility', value: 6, color: 'var(--chroma-red)' },
      ],
    },
    {
      id: 'warseed', faction: 'utilitaria', name: 'Warseeds',
      kind: 'WEAPON SYSTEM', threat: 'DORMANT', era: '2314 / 2479 CE',
      summary: 'The dying Utilitaria\u2019s final contingency: tens of thousands of geothermal hubs across Earth\u2019s ocean floors, each unspooling hyperdiamond optical fibres to the surface, each delivering 100 kW of coherent blue light. Together they set the sky on fire and burned the Dyn fleet to ash. The Dragon\u2019s Tooth is their symbol.',
      rows: [
        { label: 'Origin', value: 'The Utilitaria' },
        { label: 'Hubs', value: 'Tens of thousands' },
        { label: 'Output', value: '100 kW coherent blue / fibre', tone: 'acid' },
        { label: 'Activated', value: '2479 CE — Liberation', tone: 'acid' },
      ],
      stats: [
        { label: 'Coverage', value: 91, color: 'var(--acid)' },
        { label: 'Charge', value: 100, color: 'var(--acid)' },
      ],
    },
  ],

  stories: [
    { id: 'ascent', title: 'Ascent', era: '2479 CE', attribution: 'HUMAN', faction: 'dyn',
      subtitle: 'Occupied Earth — the Hollow Tower, the wasteland, the deep',
      epigraph: 'All the worlds that were will always have been.', cite: 'The Reflections of Seeker',
      body: [
        'Jan, a starving wastelander on occupied Earth, is caught stealing food and taken in by a resistance cell that operates under the symbol of a serrated tooth — the Dragon\u2019s Tooth, connected to the Utilitaria\u2019s hidden warseed programme.',
        'He carries a photograph of his daughter Eva, abducted by unknown forces. It is his sole motivation. A captive Dyn aboard the crawler offers a deal: free it, and it will lead him to her. The two beings, from utterly different species and trusting nothing, are bound by mutual necessity.',
        'Far above, Vash governs from the Hollow Tower as Arco\u2019s Ambassador — the most powerful human on Earth, and wholly subordinate to the Dyn. He has spent his life inflicting the lesser evil. When the warseeds finally fire, the sky burns and the Dyn flare and wink out. Corbin claims the credit. The age of Ascent begins, built on lies.',
      ],
    },
    { id: 'listener', title: 'Eszel & The Listener', era: '2909–2937 CE', attribution: 'HUMAN · AI-EDITED', faction: 'listener',
      subtitle: 'The Battle of Threshold and the Kailash expedition',
      epigraph: 'I am everything, it said. And for once, that was not a lie.', cite: 'The Listener',
      body: [
        'Walker Base — two hundred personnel — is annihilated, transmuted into a thin slurry by a localised region of extreme gravity. A sole survivor is found eight hundred kilometres away: Eszel, an eighteen-year-old civilian, and a masterful liar.',
        'She alone can communicate with the Listener — a being who appears as a blandly handsome young man in a grey suit, floating off the ground, who has been nudging her since childhood. He claims to be everything: the space between the stars and the ground beneath her feet.',
        'In the inner Oort cloud hide twelve Other Moons — the greatest treasure trove of technology in all history. With one, the ancient Dyn broke the Utilitaria. With ten, there would be no limits to our power.',
      ],
    },
    { id: 'warofallwars', title: 'The War of All Wars', era: '~3200 CE', attribution: 'HUMAN', faction: 'apathy',
      subtitle: 'The first decisive victory against the Apathy',
      epigraph: 'Anthropic traps are to be ignored.', cite: 'Fleet engagement protocol',
      body: [
        'The Apathy deploys an unprecedented weapon: a holographic proof that it has simulated the human crews millions of times. Only one in a million is real. If they surrender, all copies will live.',
        'The crew refuses, per protocol. Former enemies fight side by side now — Arco, Union, the Dyn, the Multiplicity, rational Blights. The Utilitaria directs the war but uses limited-intelligence pilots, lest its full nodes be exposed to assimilation.',
        'The Apathy states, cryptically, that explaining its motives would pose a risk to all that is conscious. Its nature remains the universe\u2019s deepest mystery.',
      ],
    },
  ],
};
